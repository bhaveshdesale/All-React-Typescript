// object typing

// FOR NOW!!
// interface = type = class
// there is a huge diff between all three
// but FOR NOW, all of them are same.

// interface => create a new type.
interface IPerson {
    name: string;
    age: number;
}

// type => create a new type.
type TPerson = {
    name: string;
    age: number;
}

// class => create a new type.
class Person {
    name = ""
    age = 0
}


const person: IPerson = {
    age: 12,
    name: "Aniruddha",
}

const person2: TPerson = {
    age: 12,
    name: "Aniruddha",
}

const person3: Person = {
    age: 12,
    name: "Aniruddha",
}

interface Bottle {
    // 
    volume: string | number;
    // 
    price: number & string;
}

let a: unknown;
a = 5;
a = "abcd";
// a.toString(); does not work!!
// forces us to narrow the type!
if (typeof a === "number") {
    a.toString();
}

if (typeof a === "string") {
    a.indexOf("");
}

function add(n1: any, n2: unknown, n3: number) {
    n1.indexOf();
    // n2.indexOf();
    if (typeof n2 === "string") {
        n2.indexOf("abcd");
    }

    if (typeof n2 === "number") {
        n2.toString();
    }
}

add(5, 7, 5);

const arr1: number[] = [];
arr1.push(5);
// arr1.push("error"); 
const arr2: (number | string)[] = [];
arr2.push(5);
arr2.push("no error");

const arr3: Person[] = [];
// arr3.push(4)
arr3.push({ age: 13, name: "123" });

interface OptionalPerson {
    name: string;
    age?: number;
}

const arr4: OptionalPerson[] = [];
arr4.push({ age: 13, name: "123" });
arr4.push({ name: "Vidhi" });

const arr5: (Person | OptionalPerson)[] = []


