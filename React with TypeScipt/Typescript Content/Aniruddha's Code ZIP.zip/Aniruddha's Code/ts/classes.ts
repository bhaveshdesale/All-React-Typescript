class Building {
    name: string;
    floors: number;
    private soldFlats = 0;

    constructor(name: string, floors: number) {
        this.name = name
        this.floors = floors
        this.soldFlats = 5;
    }
}

// shortcut of above
class Apartment {

    constructor(
        public name: string = "default",
        public floor: number,
        private soldFlats: number
    ) {}
}