const numbers: Array<number> = [];
const strings: Array<string> = [];
const bools: Array<boolean> = [];

interface CustomResponse<T> {
    data: T;
    status: string;
    code: number
}

interface User {
    name: string;
    age: number;
}

interface Product {
    color: "blue" | "black" | "yellow";
    price: number;
}

async function getData<T>(url: string): Promise<CustomResponse<T>> {
    // fetch api calls here..
    const response = await fetch(url)
    const data: CustomResponse<T> = await response.json();
    return data;
}

getData<Product>("www.example.com/product/1").then(response => {
    response.data.color
});

getData<User>("www.example.com/product/1").then(response => {
    response.data.age
});

