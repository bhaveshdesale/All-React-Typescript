

// let add = (n1: number, n2: number) => {
//     return n1 + n2;
// }

// function log(callback: Function) {
//     return (...args: unknown[]) => {
//         console.log("calling fn");
//         const result = callback(...args);
//         console.log("fn ended");
//         return result;
//     }
// }

// const decoratedAdd = log(add);
// decoratedAdd(1, 2); // calling fn, fn ended, 3

// class Dummy {}

// const classDeco = (cls: typeof Dummy) => {
//     return class extends cls {
//         constructor() {
//             super()
//         }
//     }
// }

// // Mathematics = classDeco(Mathematics)
// @classDeco
// class Mathematics {
//     // @log
//     // static subtract(n1: number, n2: number) {
//     //     return n1 - n2;
//     // }
//     // subtract = log(subtract)
// }


// @classDeco
// class NotMathematics {

// }

// function realClassDeco<T extends { new (...args: any[]): {} }>(constructor: T) {
//     return class extends constructor {
//         addedProp = "random prop added"
//     }
// }
















let add = (n1: number, n2: number) => { return n1 + n2; }

function log(callback: Function) {
    return (...args: unknown[]) => {
        console.log("calling fn");
        const result = callback(...args);
        console.log("fn ended");
        return result;
    }
}

const decoratedAdd = log(add);
console.log(decoratedAdd(1, 2)); 

class he {}
const classDeco = <T extends { new (...args: any[]): {} }>(constructor: T) => {
    return class extends constructor {
        constructor(...args: any[]) {
            super();
            console.log("Class decorated");
        }
    }
}

// Applying the decorator
@classDeco
class Mathematics {}
const m = new Mathematics();

//Robust Class Decorator (Adding properties) ---
// Generic constraint to ensure it's a constructor
function realClassDeco<T extends { new (...args: any[]): {} }>(constructor: T) {
    return class extends constructor {
        addedProp: number;
        constructor(...args: any[]) {
            super(...args);
            this.addedProp = 0;
        }
    }
}

@realClassDeco
class NotMathematics {
    constructor() {}
}

const instance = new NotMathematics();
console.log((instance as any).addedProp); // Outputs: "random prop added"


