// class App {
//     post(url: string) {
//         function decorator(originalMethod: Function, context: ClassMethodDecoratorContext<any>) {
//             return function replacer(...args: any[]) {
//                 return originalMethod.apply(this, args);
//             };
//         };
//         return decorator
//     }
// }

// const app = new App();

// class UserController {

//     @app.post("/users")
//     getUsers() {
//         console.log("getting users");
//     }
// }

