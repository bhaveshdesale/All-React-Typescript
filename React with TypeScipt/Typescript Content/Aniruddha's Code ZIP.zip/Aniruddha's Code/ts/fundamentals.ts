// type inference
let number = 5; // number
// number = "abcd"; does not work
let string = "abcd"; // string
let isScared = true; // boolean
let undef = undefined; // undefined
let nullish = null; // null
let arr = [1, 2, 3];
let object = { age: 1, name: 'a', pqrs: 12345678 };

// object["pqrs"] = 'value'; // does not work
// object.age = "7"; // does not work
object.age = 10;

// delete object["age"];

let fn = (n1: number) => {
    return 5;
}

// datatype is 'any'
// age works like js variables.
let age;
age = 6;
age = "abcd"; // this works
age.search("a")

// explicit data typing
let address: string;
address = "abcd";
// address = {} // does not work

