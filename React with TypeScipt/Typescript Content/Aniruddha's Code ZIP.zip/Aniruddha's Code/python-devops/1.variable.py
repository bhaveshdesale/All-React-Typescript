number = 10
print(number)

# defining prime_number, not assigning any value
# typing
prime_number: int
prime_number = 7
print(prime_number)