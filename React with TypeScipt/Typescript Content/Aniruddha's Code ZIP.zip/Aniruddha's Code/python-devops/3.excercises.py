# 

def get_regions(server_name, service_name):
    # server_name = "gcp"
    # service_name = "cloudrun"
    regions = {
        "aws": {
            "s3": ["east", "west"],
            "lambda": ["east"]
        },
        "gcp": {
            "cloudrun": ["north"]
        },
        "azure": {
            "blob": ["south"]
        }
    }

    return regions[server_name][service_name]

intern = {
    "name": "Aniruddha Gohad",
    "track": "DevOps",
    "mentor": "Amit Thakkar",
    "location": {
        "office": "Nyati",
        "seat_no": "NY-WS-99"
    }
}

intern["name"] # "Aniruddha Gohad"
key = "name"
intern[key] # "Aniruddha Gohad"
intern["location"]["seat_no"] # "NY-WS-99"

if "does_not_exist" in intern:
    intern["does_not_exist"] # ERROR


def get_disk_usage():
    import random
    # import psutil

    # return psutil.disk_usage()

    return random.randint(0, 100)

import subprocess

def alert_for_disk():
    disk_usage = get_disk_usage()
    print(disk_usage)
    if disk_usage > 95:
        print("Extremely High")
    elif disk_usage > 80:
        print("Moderately High")
    elif disk_usage > 50:
        print("High")
    else:
        print("disk usage optimal")

alert_for_disk()
    


