
def loan_factory(r):
    def loan_calc(p, n):
        return p * n * r / 100
    
    def change_rate(new_rate):
        nonlocal r
        r = new_rate
    
    return [loan_calc, change_rate]

home_loan_calc, change_home_loan_rate = loan_factory(8)
personal_loan_calc, change_personal_loan_rate = loan_factory(10)
car_loan_calc, change_car_loan_rate = loan_factory(12)

print(home_loan_calc(10000, 12))
print(car_loan_calc(10000, 12))
change_home_loan_rate(9)
print(home_loan_calc(10000, 12))

numbers = [1, 2]
one = numbers[0]
two = numbers[1]

# unpacking
one, two = numbers
print(one, two)








def counter_factory(starting_num):
    def counter():
        nonlocal starting_num
        starting_num += 1
        return starting_num
    
    return counter

count_from_10 = counter_factory(10)
count_from_100 = counter_factory(100)

count_from_10() # 11
count_from_10() # 12
count_from_10() # 13

count_from_100() # 101
count_from_100() # 102
count_from_100() # 103






def greet():
    return "hello"

def log(fn):
    # fn = greet
    def replacement():
        print('calling fn')
        return fn()

    return replacement

greet = log(greet)
# *args, **kwargs
# greet = replacement

# get_name = log(get_name)

@log
def get_name():
    return "aniruddha"

print(get_name())

print(greet())
# calling fn
# hello

