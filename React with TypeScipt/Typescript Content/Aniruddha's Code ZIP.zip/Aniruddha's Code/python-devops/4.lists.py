numbers = [1, 2, 3]

map(lambda n: n * n, numbers)

def transform(arr, operate):
    # arr = [1, 2, 3]
    # operate = toAlpha

    transformed_list = []
    # ["a", "b"]

    for elem in arr:
        # elem = 2
        transformed_elem = operate(elem)
        # transformed_elem = "b"
        transformed_list.append(transformed_elem)

    return transformed_list

def toAlpha(number):
    if(number > 26 or number < 1):
        return "Invalid Number"
    alpha = "abcdefghijklmnopqrstuvwxyz"
    return alpha[number - 1]

squares = transform(numbers, lambda e: e * e)
alphas = transform(numbers, toAlpha)
even_odds = transform(numbers, lambda e: not (e % 2 == 0))
map(toAlpha, numbers)

print(squares)
print(alphas)
print(even_odds)


import functools

def filter_a(arr, predicate):
    # predicate = lambda n: n % 2 == 1
    filtered_list = []

    for elem in arr:
        if predicate(elem):
            filtered_list.append(elem)

    return filtered_list

numbers = [1, 2, 3 ,4, 5]

import math

def is_prime(number):
    if number < 2:
        return False
    
    if number == 2:
        return True
    
    for count in range(2, int(math.sqrt(number))):
        if number % count == 0:
            return False
        
    return True

# odds = filter(numbers, lambda n: n % 2 == 1)
# evens = filter(numbers, lambda n: n % 2 == 0)
# divisible_by_5 = filter(numbers, lambda n: n % 5 == 0)
# all_primes = filter(numbers, is_prime)

# print(odds, evens, divisible_by_5, all_primes)

def loan_factory(r):
    # r = 8 (pass by value)
    # loan_calc (pass by reference)
    def loan_calc(p, n):
        return p * n * r / 100
    
    return loan_calc # return the reference of the loan_calc fn
    
home_loan_calc = loan_factory(8)
# reference of the loan_calc fn

personal_loan_calc = loan_factory(12)
# reference of the loan_calc fn

car_loan_calc = loan_factory(10)
# reference of the loan_calc fn

# r = 8
print(home_loan_calc(1000000, 24))
# r = 8 => 8.5
# home_loan_calc = loan_factory(8.5) => NOT THIS
# 
print(home_loan_calc(1000000, 24))




def add(n1, n2):
    return n1 + n2

add(4, 3)
num = 5

num

print(num)