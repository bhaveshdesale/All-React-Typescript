# numerical

integer: int = 10
floating: float = 10.5

sentence: str = 'this is a single quoted string'
sentence: str = "this is a doule quoted string"
sentence: str = """this is a doc string. 
I can have a multi line string directly
"""

sentence: str = '''
a single quoted multiline doc string
'''

is_sleepy: bool = True
is_hungry: bool = False

# NEVER DO THIS!
PPOs: None = None


# greet is the variable which refers to the function
def greet():
    print("hellooooo")

print(type(greet))

# list
random = [1, "aws", 10.5, True, None, [1, 2, 3], (1, 2, 3), {
    "name": "1234"
}, greet]

# tuples (lists but fixed size and immutable)
numbers = (1) # not a tuple => this is a number
numbers = (1, ) # a tuple
numbers = (2, greet)

# dict
person = {
    "name": "aniruddha",
    "age": 10,
    "has_brains": True,
    "girlfriend": None,
    "friends" : ["a", "b", "c"],
    "address": {
        "city": "Pune",
        "country": "IN"
    },
    "greet": greet
}

print(greet)

