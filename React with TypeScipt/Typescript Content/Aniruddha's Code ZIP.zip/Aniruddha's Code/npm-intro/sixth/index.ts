console.log("abcde");

function add(n1: number, n2: number) {
    return n1 + n2;
}

add(1, 2);

export default add;