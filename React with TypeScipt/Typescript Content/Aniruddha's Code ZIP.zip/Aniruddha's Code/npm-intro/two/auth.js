import db from "./db.js"

const login = (username, password) => {
    db.db();
}

export default {
    login
}