import auth from "./auth.js"

auth.login("a", "b")