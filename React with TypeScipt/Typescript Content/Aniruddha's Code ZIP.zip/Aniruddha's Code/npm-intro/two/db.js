
const db = () => {
    console.log('getting things from db...');
}

export default {
    db
}