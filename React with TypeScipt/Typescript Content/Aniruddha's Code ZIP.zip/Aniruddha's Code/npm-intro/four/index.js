function add(n1, n2) {
    return n1 + n2;
}

export default {
    add
}

add(1, "8"); // 18