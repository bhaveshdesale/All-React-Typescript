import math from "./index.js";

math.add(7, 6);
