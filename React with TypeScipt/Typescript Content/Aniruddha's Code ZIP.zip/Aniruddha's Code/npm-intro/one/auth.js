const db = require("./db")
// const { db } = require("./db");

const login = (username, password) => {
    db.db();
}

module.exports = {
    login
}