// const { login } = require("./auth");
const auth = require("./auth");

auth.login("a", "a");