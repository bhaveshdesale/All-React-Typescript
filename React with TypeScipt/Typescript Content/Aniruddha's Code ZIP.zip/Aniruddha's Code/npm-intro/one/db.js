

const db = () => {
    console.log('getting things from db...');
}

// module.exports = db;
module.exports = {
    db
}