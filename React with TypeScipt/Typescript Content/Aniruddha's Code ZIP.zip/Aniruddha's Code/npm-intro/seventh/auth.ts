import db from "./db.js";


const login = () => {
    console.log('logging in');
    db.get();
}

export default {
    login
}