

const get = () => {
    console.log('getting data from db');
}

export default {
    get
}