import auth from "./auth.js"

const main = () => {
    console.log('starting app...');
    auth.login();
}

main();