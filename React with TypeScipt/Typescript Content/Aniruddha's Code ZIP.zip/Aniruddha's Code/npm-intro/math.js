const add = () => "addition";
const subtract = () => "subtraction";

// default export
// can be of ANY datatype
export default {
    add,
    subtract
}

// export default 1;
// export default "string exported"
// export default false
// export default undefined
// export default null;
// export default [
//     1, 2, 3
// ]
// export default () => {
//     console.log('a function can be exported')
// }


// NAMED EXPORTS
export const multiply = () => "product";
export const divide = () => "divide";

// COMMONJS IMPORT AND EXPORT SYNTAX
// module.exports = {
//     add,
//     subtract
// }