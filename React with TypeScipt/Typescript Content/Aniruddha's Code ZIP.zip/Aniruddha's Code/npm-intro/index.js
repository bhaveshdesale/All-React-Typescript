// COMMONJS IMPORT AND EXPORT SYNTAX
// const math = require("./math.js");

// default import
// you can name imports whatever you want
import math from "./math.js";
import m2 from "./math.js";

const { add, subtract } = math;

// named import
// NOT DESTRUCTURING!!!!
import { multiply as product, divide } from "./math.js";

product();
divide();

console.log("this is what gets run", m2);

console.log(math.add());
console.log(m2.subtract());
console.log(m2.multiply());