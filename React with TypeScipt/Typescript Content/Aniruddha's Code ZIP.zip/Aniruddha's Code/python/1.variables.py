number: int
number: str

# number = 10.5
print(number)
name: str = "Aniruddha"

movie_name: str = "DDLJ"
duration: int = 120
rating: int = 4