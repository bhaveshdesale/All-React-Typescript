def greet(a):
    print('hiii')

greet # reference to greet function.
greet("abcd") # executing fn

gg = greet

greet = 5
print(greet)

def greet_person(name: str):
    print(f"heeloooo {name}")

# greet_person() # Error
greet_person(5) # heeloooo 5
greet_person("Aniruddha")
# greet_person("ani", 5) # Error

def get_greeting():
    return "Heyloo"

gg = get_greeting
gg()

greeting = get_greeting()

def create_greeting(name):
    greeting = get_greeting()
    return f"{greeting} {name}"

print(create_greeting("Aniruddha"))


def dummy():
    message = 'hi'
    return

print(dummy())

# lambda

add = lambda n1, n2: n1 + n2

add(1, 2) # 3

def print_details(name, age, address):
    print(name, age, address)


print_details("Aniruddha", 32, "Kothrud") 
print_details(name="Aniruddha",age = 32, address="kothrud")
print_details(address="abcd", name="pqrs", age=32)
print_details("abcd", address="pqr", age=32)
person = {
    "name": "aniruddha",
    "age":20,
    "address": "pune"
}
print_details(**person)

person = ["a", 32, "p"]
print_details(*person)

def store_details(name, age, /, address, *, number, shoe_size):
    pass

# store_details(1, 2, 3, 3, shoe_size=6)

def print_text(text, *, outline = False):
    if(outline):
        print("============")
    print(text)
    if(outline):
        print("============")

print_text(1234567890, outline=True)

def list_args(one, two, /, *pos, three):
    pass

list_args()
