

def partial(fn, *args, **kwargs):
    def replacer(*arg, **kwarg):
        return fn(*args, *arg, **kwargs, **kwarg)
    
    return replacer

def add(n1, n2):
    return n1 + n2

add_five = partial(add, 5)
print(add_five(6))

def get_data(table_name):
    print(f"getting data from {table_name}")

get_users = partial(get_data, "users")
get_products = partial(get_data, "products")
get_users()
get_products()
