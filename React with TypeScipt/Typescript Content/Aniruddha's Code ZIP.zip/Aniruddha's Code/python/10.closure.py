

def calculator_factory(r):
    def calculator(p, n):
        return p * n * r

    def change_rate(new_rate):
        nonlocal r
        r = new_rate
    
    return [calculator, change_rate]

car_loan_calc, update_car_loan_rate = calculator_factory(8)
home_loan_calc = calculator_factory(10)
personal_loan_calc = calculator_factory(12)

print(car_loan_calc(1000, 12))
update_car_loan_rate(12)
print(car_loan_calc(1000, 12))

def configuration(pattern):
    def outline(callback):
        def decorator(*args, **kwargs):
            result = callback(*args, **kwargs)
            print(pattern * 5)
            print(result)
            print(pattern * 5)

        return decorator
    return outline

@configuration("=")
def add(n1, n2):
    return n1 + n2

def multiply(n1, n2, n3):
    return n1 * n2 * n3

@configuration("#")
def add_five(n1):
    return n1 + 5



# add = outline(add)

add(1, 2)

# multiply = outline(multiply)
# add_five = outline(add_five)


def log(starting_text, ending_text):
    def decorator(callback):
        def deco(*args, **kwargs):
            print(f"{starting_text}")
            result = callback(*args, **kwargs)
            print(f"{ending_text}")
            return result
        
        return deco
    
    return decorator

@log("subtract called", "subtraction done")
def subtract(n1, n2):
    return n1 - n2

# subtract = log("subtract called", "subtraction done")(subtract)

diff = subtract(n1=4, n2=2) # 2

print(diff)

def gen():
    n = 2
    yield 10
    n = yield n
    yield n

g = gen()
for elem in g:
    print(elem)
    g.send(50)