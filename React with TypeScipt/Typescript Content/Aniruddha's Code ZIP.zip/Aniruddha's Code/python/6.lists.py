#          0   1   2   3   4
numbers = [10, 20, 30, 40, 50]
#         -5   4   3   2   1

len(numbers) # 5
list.__len__(numbers)
numbers.__len__()

# modify elements
numbers[0] = 10

# access elements
numbers[0] # 10
numbers[-1] # 50

print(numbers)
# add to a list
numbers.append(60) 
#  [10, 20, 30, 40, 50, 60]
print(numbers)
numbers.insert(0, 0)
#  [0, 10, 20, 30, 40, 50, 60]
print(numbers)
numbers.insert(4, 35)
#  [0, 10, 20, 30, 35, 40, 50, 60]
print(numbers)
numbers.pop()
#  [0, 10, 20, 30, 35, 40, 50]
print(numbers)
numbers.pop(0)
#  [10, 20, 30, 35, 40, 50, 60]
print(numbers)
numbers.remove(35)
#  [10, 20, 30, 40, 50, 60]
print(numbers)

del numbers[0]
print(numbers)

numbers = numbers[:-1]
print(numbers)

gautami_friends = ["Arya", "Aditi"]
# copies the reference of gautami_friends
anjali_friends = gautami_friends

print(gautami_friends)
print(anjali_friends)

anjali_friends.append("Nihar")
anjali_friends.append("Ishita")

print(gautami_friends)
print(anjali_friends)

# creates a shallow copy
nihar_friends = anjali_friends[::]
print(nihar_friends)

nihar_friends.append("Aniruddha")
print(nihar_friends)
print(anjali_friends)

anshika_friends = [
    { "name": "Anwesha", "mobile": 12357890 },
    { "name": "Anupriya", "mobile": 98765421 },
]

harsh_friends = anshika_friends[::]
harsh_friends[0] #  { "name": "Anwesha", "mobile": 12357890 }
harsh_friends[0]["mobile"] # 12357890
harsh_friends[0]["mobile"] = 57657575

print(harsh_friends)
print(anshika_friends)

harsh_friends.append({"name": "Yash", "mobile": 45678432})

print(anshika_friends)

# unpacking
eventDetails = [
    { "name": "secret", "time": "5:30 pm" },
    { "name": "sports day", "time": "5:30 pm" },
    { "name": "sports day", "time": "5:30 pm" },
    { "name": "sports day", "time": "5:30 pm" },
]

# secretEvent = eventDetails[0]
# sportEvent = eventDetails[1]

secretEvent, sportEvent, _, _ = eventDetails

print(secretEvent, sportEvent, _)

# rest *
*siddhi, = eventDetails
print(siddhi)


eventDetailsClone = [*eventDetails]
print(eventDetailsClone)

odd_nums = [1, 3, 5]
even_nums = [2, 4, 6]

combined = [*odd_nums, *even_nums]
print(combined)


# ===== tuples =====

names = ("Ani", "Riya", "Arya")
names[0] # Ani
# names[7] # Error
names[::] # shallow copy

names.index("Ani") # 0
names.count("Ani") # 1

len(names)

names = (*names, "Nihar", (1,2,3), [1,2,3])
names[5][0] = 10
print(names)

names = names[:-1]
print(names)