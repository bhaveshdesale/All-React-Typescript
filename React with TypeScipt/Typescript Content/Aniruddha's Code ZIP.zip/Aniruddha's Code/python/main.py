from util import utils
from util import subtract

utils.add(1, 2)
subtract(3,4)

class LLMHandler:
    def __entry__(self, llm):
        pass

    def __exit__(self):
        pass


with LLMHandler("openai/gpt-5.3") as openai:
    openai.call("what is the capital of france?")

with LLMHandler("gemma-120bn") as gemini:
    gemini("how many r's in strawberry?")