cricket_player = {
    "name": "Mahendra",
    "surname": "Dhoni",
    "age": 43,
    "can_bat": False,
    "captaincy": None,
    "last_five_inning": [0, 10, 20, 0, 30],
    "formats": ("ODI", "Test", "T20"),
    "address": {
        "city": "Ranchi"
    },

}

# access 
cricket_player["can_bat"] # False
key = "surname"
cricket_player[key] # Dhoni

# modify
cricket_player["can_bat"] = True
cricket_player[key] = "Singh Dhoni"

# add
cricket_player["wife"] = "Sakshi"
new_key = "country"
cricket_player[new_key] = "India"

print(cricket_player)

person = {
    "name": "Aniruddha",
    "age": 32,
    "address": "Kothrud"
}

# keys
name, *rest = person.values()
print(name, rest)

# **
personClone = {**person}
print(personClone)

def greet():
    print("hello")
    return [123567, 3457]

key = "volume"
numbers = (1,2,)
volume = "1ltr"

bottle = {
    key: volume,
    numbers: "1235790-",
    greet: "greet",
    greet: "1234567",
    "a": 1,
    "a": greet,
    volume: key
}

print(bottle[greet])