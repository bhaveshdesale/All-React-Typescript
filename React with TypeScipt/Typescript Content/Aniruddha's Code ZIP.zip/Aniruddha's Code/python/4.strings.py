name = "Shirley"
greeting = "Helloooooo"

# concat
full_greeting = greeting + " " + name

full_greeting = f"{greeting} {name}"

full_greeting = greeting.join(" ").join(name)

print(len(full_greeting)) # 18
print(str.__len__(full_greeting))
print(full_greeting.__len__())

word = "nose"
print(id(word))
word = "pose"
print(id(word))
word[0] # p
# word[0] = "n"
word = word.replace("p", "n")
print(id(word))
print(word)

#         012345
string = "bottle"
#        -654321

# slice
string[0] # b
string[5] # e
# string[6] # IndexError: string index out of range
string[-6] # b

print(string[-6:2:-1]) #


#               012345678
another_word = "firetruck"
#              -987654321

print(another_word[1:6])
print(another_word[-8:-3])
print(another_word[-8:6])
print(another_word[1:-3])

# cre
print(another_word[7:2:-2])
print(another_word[-2:-7:-2])


another_word = "Aniruddha"
another_word[::-3]