
greet_HR = lambda: "Hiiiiii"
greet_employee = lambda: "haddd"

def greet(callback):
    message = callback()
    print(message)


greet(greet_HR)
greet(greet_employee)


def map(iterable, modifier_fn):
    modified_list = []
    for elem in iterable:
        modified_elem = modifier_fn(elem)
        modified_list.append(modified_elem)

    return modified_list

map([1, 2, 3, 4], lambda n: f"{n ** 2}")
map([1, 2, 3, 4], print)
map([1, 2, 3, 4], lambda n: f"{n}")

print(map([1, 2, 3, 4],lambda n: "abcdefghijklmnopqrstuvwxyz"[n - 1]))

def get_student_details(roll_no):
    students = [
        { "name": "Arya", "roll_no": 1 },
        { "name": "Nikita", "roll_no": 2 },
        { "name": "Ishita", "roll_no": 3 },
        { "name": "Priyanshu", "roll_no": 4 },
        { "name": "Suyog", "roll_no": 5 },
    ]

    for student in students:
        if student["roll_no"] == roll_no:
            return student
        
map([1,2,3,4,5], get_student_details)


def filter(iter, predicate):
    filtered_iter = []

    for elem in iter:
        if predicate(elem):
            filtered_iter.append(elem)
    
    return filtered_iter

filter(["abc", "pqr", "lmno"], lambda s: len(s) > 3)

def find(iter, predicate):
    for elem in iter:
        if predicate(elem):
            return elem
        
def find_index(iter, predicate):
    index = 0
    for elem in iter:
        if predicate(elem):
            return index
        index += 1
    return -1

def every(iter, predicate):
    for elem in iter:
        if not predicate(elem):
            return False
        
    return True

def some(iter, predicate):
    for elem in iter:
        if predicate(elem):
            return True
        
    return False

def reduce(list, reducer, default_value = None):
    output = default_value if default_value != None else list[0]
    starting_index = 0 if default_value != None else 1

    for index in range(starting_index, len(list)):
        output = reducer(output, list[index])

    return output


print(reduce([1,2,3], lambda acc, curr: acc + curr, 10))