num1: int = 10
num2: int = 2

addition: int = num1 + num2
difference: int = num1 - num2
product: int = num1 * num2
quotient: float = num1 / num2 # full quotient
floor: int = num1 // num2 
remainder: int = num1 % num2
exponent: int = num1 ** num2

import math

math.floor(4.5) # 4
math.floor(4.9) # 4

math.ceil(4.1) # 5
round(4.5) # 5
round(4.4) # 4

import random

# print(random.random()) # between 0 and 1, excluding 0 and 1

print(round(random.random() * 5 + 10))
