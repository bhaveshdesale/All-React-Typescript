import FastAPI


app = FastAPI()