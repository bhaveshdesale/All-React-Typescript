True and True # T
True and False # F
False and False # F
False and True # F

True or True # T
True or False # T
False or False # F
False or True # T

# first truthy value
message = "" or "default message"
# last falsy value
message = 0 or None
print(message)

# first falsy value
message = "" and "default message"

# last truthy value
message = 10 and 5
print(message)

employee_role = ["director", "manager"]

if "director" in employee_role:
    print("cabin")
elif "team lead" in employee_role:
    print("small cabin")
elif "delivery manager" in employee_role:
    print("corner seat")
else:
    print("floor")

customer_age = 27
third_floor_threshold = 25
second_floor_threshold = 18


if customer_age >= third_floor_threshold:
    print("third flooor")
elif customer_age >= second_floor_threshold:
    print("second flooor")
else:
    print("first floor")

message = "third floor" if customer_age >= third_floor_threshold else "second floor" if customer_age >= second_floor_threshold else "first floor"


# message = "something" if role == "director" else "something else"



print(([] or 0 or "0") and (False == [] == 0) or (not [] is False and (True + True) * False or "done"))
([] or 0 or "0") # "0"
print((False == [] == 0))