import json

person = {
    "name": "Priyanshu",
    "is_tensed": False
}

# stringified data in a certain format.
# '{ "name": "Priyanshu", "is_tensed": false }'

# dumps => converts python datatypes to json string format
print(type(json.dumps(person)))
# '{ "name": "Priyanshu", "is_tensed": false }'

# NOT JSON FORMAT.
print(person.__str__())
# {'name': 'Priyanshu', 'is_tensed': False}

print(json.dumps(1))  # '1'
print(json.dumps(1.2))  # '1.2'
print(json.dumps('this is a str'))  # '"this is a str"'
print(json.dumps(None)) # 'null'
print(json.dumps([1, 2, '4'])) # '[1, 2, "4"]'
print(json.dumps({ "name": 1, "surname": 'abcd' })) # '{ "name": 1, "surname": "abcd" }'
# print(json.dumps(lambda x: x)) # ERROR

body = '{ "name": 1, "surname": \'abcd\' }'
body = json.loads(body)

print(type(body), body)