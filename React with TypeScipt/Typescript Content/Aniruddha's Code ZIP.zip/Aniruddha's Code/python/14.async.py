import asyncio
# normal function
def greet():
    print("greet called")

# function called and executed
greet()

# async creates a coroutine
# calling greet() results in a coroutine object
async def greet():
    print("greet called")
    await asyncio.sleep(5)
    print("greet end")

async def greet2():
    print("greet2 called")
    await asyncio.sleep(3)
    for i in range(100000):
        print(i)
    print("greet2 end")

# result = greet()

# print(result)

# await can only be inside a async function
async def main():
    print("before 'awaiting'")
    # pause the execution of main
    # await result
    # await greet2()

    t1 = asyncio.create_task(result)
    t2 = asyncio.create_task(greet2())

    # await t1
    # await t2
    await asyncio.gather(t1, t2)
    
    # for i in range(100):
    #     print(i)

    print("after 'awaiting'")


# run takes a coroutine
# "schedules" or runs the coroutine in the CPU
# asyncio.run(main())

# print('end')


# import requests

keywords = ['apple', 'bitcoin', 'media']
query = 'q=('
for keyword in keywords:
    query += keyword
    query += ' AND '

query = query[:-5]
query += ")"

print(query)