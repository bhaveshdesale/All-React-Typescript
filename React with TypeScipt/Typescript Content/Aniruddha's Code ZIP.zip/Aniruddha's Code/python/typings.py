from typing import Optional, NewType, Any, TypeVar, Generic, TypedDict

type user = dict[str, str | int]

type R = int
type G = int
type B = int
RGBColor = NewType('RGBColor', tuple[R, G, B])

type H = int
type S = int
type L = int
HSLColor = NewType('HSLColor', tuple[H, S, L])

print(type(user))

class User(TypedDict):
    first_name: str
    last_name: str
    email: str
    favorite_color: Optional[RGBColor | HSLColor] = None
    age: Optional[int] = None


def create_user(
        first_name: str, 
        last_name: str, 
        favorite_color: Optional[RGBColor | HSLColor] = None, 
        age: Optional[int] = None
    ) -> User:
    email = f"{first_name}.{last_name}@coditas.com"

    return {
        "first_name": first_name,
        "last_name": last_name,
        "email": email,
        "favorite_color": favorite_color,
        "age": age or 0
    }


user1 = create_user("aniruddha", "gohad", HSLColor((10, 20, 30)), 20)
user2 = create_user("aditi", "rathi", RGBColor((124, 243, 88)), 21)

print(user1["first_name"])


def unknown_params(a_string: Any):
    # a_string does not get any intellisense here
    # try NOT to use Any (implicit or explicit)

    # type narrowing
    if(type(a_string) == str):
        a_string.capitalize()

    # type narrowing but better
    if(isinstance(a_string, str)):
        a_string.capitalize()

T = TypeVar("T")
class Box(Generic[T]):
    def __init__(self, value: T):
        self.value = value

    def get(self):
        return self.value
    

box1 = Box(10)
box1.value # int

box2 = Box("SIDE")
box2.value # str


##### USING PYDANTIC ######
from pydantic import BaseModel, Field, ValidationError, EmailStr, field_validator

class User(BaseModel):
    name: str = Field(min_length=5, max_length=10)
    age: int = Field(gt=18,  strict=True)

    @field_validator("name")
    @classmethod
    def check_name(cls, value: str):
        if value.startswith("/"):
            raise ValueError("invalid name")
        return value
        
    
    @field_validator("name")
    @classmethod
    def strip_name(cls, value: str):
        print(value)
        return value.strip()

try:
    user3 = User(name="abcd   ", age=19)
except ValidationError as e:
    print(e)

print(len(user3.name))
