positive_number: int = 10
negative_number: int = -10
print(type(positive_number)) # 

lens_number: float = 0.75
print(type(lens_number))

single_quoted_str: str = 'this is a stirng'
double_quoted_str: str = "this is also a string"
doc_string: str = """this is a doc stirng"""

is_hungry: bool = True
is_bored: bool = False

none_val = None
print(type(none_val))

# list
numbers = [1, 2, 3, 4]
person = [
    "Aniruddha",
    32,
    False,
    None,
    ["A", "B", "C"],
    ("t1", 2, 3),
    {
        "city": "Pune",
        "country": "India"
    }
]

# tuples
person_tuple = (
    "Aniruddha",
    32,
    False,
    None,
    ["A", "B", "C"],
    ("t1", 2, 3),
    {
        "city": "Pune",
        "country": "India"
    }
)

name_tuple = ("Aditi", )
print(type(name_tuple))

# dicts
person = {
    "name": "Aniruddha",
    0: "abcd",
    "age": 32,
    "has_brain": False,
    "girlfriend": None,
    "friends": ["A", "B", "C"],
    "movies": ("t1", 2, 3),
    "address": {
        "city": "Pune",
        "country": "India"
    },

    # []: "abcd",
    # key: "value"
}

def greet():
    print("heelloooooooooo")

print(type(greet))