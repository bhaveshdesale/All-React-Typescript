

class Dummy:
    def __init__(self):
        self.value = 5

    def __str__(self):
        return f"the __str__ is {self.value}"
    
    def __repr__(self):
        return f"{self.value}"
    
dummy = Dummy()
# print(dummy + 5)
print(dummy)
print(str(dummy))