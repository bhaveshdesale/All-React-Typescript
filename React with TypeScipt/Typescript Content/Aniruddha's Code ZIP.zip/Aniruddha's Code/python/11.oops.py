bottle = {
    "volume": 1,
    "price": 120,
    "manufacturer": "abcd"
}

bottle1 = {
    "volume": 2,
    "price": 240,
    "manufacturer": "pqrs"
}

volume = 3
# price = 400
manufacturer = "milton"

# bottle2 = {
#     "volume": volume,
#     "price": price,
#     "manufacturer": manufacturer
# }

bottle2 = {}

bottle2["volume"] = volume

class Bottle:
    # name = "aniruddha
    pass

class Building():
    age = 5
    # constructor
    def __init__(self, name):
        # this = self. self is NOT a keyword.
        # the first parameter is always the "this" 
        # you can name it anything.
        self.name = name
        # self.age = 10
    
    def change_name(self, new_name):
        self.name = new_name

    @staticmethod
    def change_age(new_age):
        Building.age = new_age


building = Building("Nyati")
building2 = Building("Gaia")
bottle = Bottle()

print(building.name)
print(Building.age)

# not preferred
building2.cage = 10
print(building2.cage)

building.change_name("Bhairav")
Building.change_name(building, "Bhairav")
# building.age = 26
print("============")
print(Building.age)
print(building.age)
print("============")
building.change_age(10)

print("============")
print(Building.age)
print(building.age)
print("============")
Building.change_age(15)

print("============")
print(Building.age)
print(building.age)
print("============")

Building.age = 20
print("============")
print(Building.age)
print(building.age)
print("============")
# print(bottle.name)

import json
class Product:
    def __init__(self, name, price):
        self.name = name
        self.price = price

    def save(self):
        print('saving product')

    @classmethod
    def from_json(cls, json_str):
        product_dict = json.loads(json_str)
        return cls(product_dict["name"], product_dict["price"])
    
    def to_json(self):
        return json.dumps({ "name": self.name, "price": self.price })

    
product = Product("remote", 150)

json_str = '{ "name": "chair", "price": 300 }'

prod = Product.from_json(json_str)

print(Product.to_json(product))



class Sport:
    def __init__(self):
        print("constructor of sport")
        super().__init__()

class Game:
    def __init__(self):
        print("constructor of game")
        super().__init__()

class Fifa(Sport, Game):
    def __init__(self):
        super().__init__()

class Controller(Fifa):
    def __init__(self):
        super().__init__()

# fifa = Fifa()

print(Controller.mro())

