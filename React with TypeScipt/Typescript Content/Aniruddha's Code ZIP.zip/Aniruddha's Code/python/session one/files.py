# file handling

with open("session.md", "r") as f:
    for line in f:
        print(line)