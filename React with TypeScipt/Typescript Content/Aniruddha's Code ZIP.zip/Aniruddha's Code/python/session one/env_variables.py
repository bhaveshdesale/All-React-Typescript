import os
from dotenv import load_dotenv

load_dotenv()

# simple use case
PORT = os.getenv("PORT")
print(PORT)

# pydantic way:

from pydantic_settings import BaseSettings, SettingsConfigDict, TomlConfigSettingsSource

class Settings(BaseSettings):
    PORT: int

    model_config = SettingsConfigDict(
        # with .env
        env_file = "../.env"
    )

settings = Settings()
print(settings.PORT)

class AppSettings(BaseSettings):
    model_config = SettingsConfigDict(toml_file="settings.toml")

    PORT: int

    @classmethod
    def settings_customise_sources(cls, settings_cls, **kwargs):
        return (TomlConfigSettingsSource(settings_cls),)

app_settings = AppSettings()

print(app_settings.PORT)

# Dynaconf way

from dynaconf import Dynaconf

dyna_settings = Dynaconf(
    settings_files = ["settings.toml"],
    environments = True,
    env = "prodtion"
)

print(dyna_settings.PORT)
