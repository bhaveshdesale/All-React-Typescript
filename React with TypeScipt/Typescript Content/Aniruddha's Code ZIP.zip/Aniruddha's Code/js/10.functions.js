// traditional fns

function greet() {
    console.log('hellooooooo');

    // implicit return statement -> return undefined
}

greet; // reference to the function
greet(); // undefined

function greetPerson(name) {
    const message = `Hellooooo ${name}`;
    console.log(message);
}

greetPerson; // ref
greetPerson("anirrudha", "abcdd"); // undefined

function getGreeting() {
    return 'heelllooooooooooo';

    console.log('abcd')
}

getGreeting(); // 'heelllooooooooooo'

function createGreeting(name) {
    const greeting = getGreeting();
    return `${greeting} ${name}`;
}

createGreeting("abcd"); // 'heelllooooooooooo abcd'

// store the ref of the fn in createMessage
const createMessage = createGreeting;

const add = function(n1, n2) {
    return n1 + n2
}

add; // ref of the fn
add(1, 3); // 4

// fat arrow function
// =>

const subtract = (n1, n2) => {
    return n1 - n2;
}

subtract; // ref
subtract(5, 2); // 3

// if 1 parameter -> omit ()
// if only 1 statement -> omit scope -> omit return
const multiplyBy5 = n1 => n1 * 5;

multiplyBy5(5); // 25



const three = () => {
    console.log('three');
}

const two = () => {
    three();
    console.log('two');
}

const one = () => {
    two();
    console.log('one');
}

one();