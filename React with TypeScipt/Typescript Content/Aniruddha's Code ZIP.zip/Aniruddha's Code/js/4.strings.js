const name = "Anantapadmanabhan";
const greeting = "Hellooooooo";

// concatenate/join/merge
// old way +
let fullGreeting = greeting + " " + name;

// new way es6+
// template literals
fullGreeting = `${greeting} ${name}`;

// property
const length = name.length;
// 17

// accessing substrings
//            012345
const word = "bottle";
word[0]; // b
word[-1]; // e -> not valid -> undefined
word[5]; // e
word[2]; // t
word[10]; // ERROR -> undefined
word = "Bottle";

// modify strings
const organ = "nose";
organ[0]; // n
organ[0] = "p"; // does not work. fails silently. no error

// methods
const sentence = "I|am|hungry";

// split
sentence.split("|"); // ["I", "am", "hungry"];

// substring
// sentence.substr() deprecated
// ending index is excluded
sentence.substring(2, 4); // am 

sentence.replace("a", "i"); // NEW string is returned. OG string is not affected


const companyDetails = "Coditas, 11, Nyati";
const companyDetailsList = companyDetails.split(", ");

const companyName = companyDetailsList[0];
const companyYears = companyDetailsList[1];
const companyLocation = companyDetailsList[2];

const companySummary = `
    company name: ${companyName} [${companyName.length}], 
    years in operation: ${companyYears} [${companyYears.length}],
    company location: ${companyLocation} [${companyLocation.length}]
`