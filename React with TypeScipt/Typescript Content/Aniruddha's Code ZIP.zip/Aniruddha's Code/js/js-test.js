var a = (b = 1) + (2, 3);
console.log(a, b);

var x = 10;
function f() {
  console.log(x);
  var x = 20;
}
f();

var output = (function(x){
  delete x;
  return x;
})(0);
console.log(output);

(function(){
  var a = b = 3;
})();

console.log("a defined? " + (typeof a !== 'undefined'));
console.log("b defined? " + (typeof b !== 'undefined'));

var x = (function() {
  return (1,2,3);
})();
console.log(x);

var x = (function() {
  return (1,2,3,4);
})();
console.log(x);
(function(x) {
  console.log(x);
})(x);
console.log(x);

(function f() {
  function f() { return 1; }
  return f();
  function f() { return 2; }
})();

var x = (function f(n) {
  return ((n > 1) ? n * f(n-1) : n);
})(5);
console.log(x);

class App {
  post(url) {
    function decorator(callback) {
      function replacer(...args) {
        callback(...args);
      }
      return replacer
    }
    return decorator
  }
}

const app = new App();

function getUsers() {
  console.log('getting users');
}

getUsers = app.post("/users")(getUsers);


class Stream {
  constructor() {
    this.subscribers = {
      on: [],
      end: []
    };
  }
  on(cb) {
    this.subscribers.on.push(cb)
  }

  end(cb) {
    this.subscribers.end.push(cb)
  }

  stream(chunk) {
    for(let handler of this.subscribers.on) {
      handler(chunk);
    }
  }

  streamEnd() {
    for(let handler of this.subscribers.end) {
      handler();
    }

    this.subscribers = { on: [], end: [] }
  }

}

const stream = new Stream();

let allChunks = ""
stream.on(chunk => {
  console.log('recieved chunk:', chunk);
  allChunks += chunk;
});
stream.end(() => console.log("done", allChunks));

stream.stream("a");
stream.stream("b");
setTimeout(() => {
  stream.stream("c");
}, 5000);
setTimeout(() => {
  stream.stream("d");
}, 6000);

setTimeout(() => {
  stream.streamEnd();
}, 6500);