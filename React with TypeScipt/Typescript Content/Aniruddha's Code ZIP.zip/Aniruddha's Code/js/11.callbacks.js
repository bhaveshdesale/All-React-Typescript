// fn passed to a fn as a parameter is a callback

const greetAdmin = () => 'Hey Admin';
const greetEmployee = () => 'Hi Employee';

const greet = (callback) => {
    const message = callback();
    console.log(message);
}

greet(greetAdmin);
greet(greetEmployee);


const modifyArray = (originalArr, modifierFn) => {
    const modifiedArray = [];

    for(let index = 0; index < originalArr.length; index++) {
        modifiedArray.push(
            modifierFn(
                originalArr[index], 
                index, 
                originalArr
            )
        );
    }

    return modifiedArray;
}

const filterArr = (originalArr, predicate) => {
    const filteredArr = [];

    for(let index = 0; index < originalArr.length; index++) {
        const elem = originalArr[index];

        if(predicate(elem, index, originalArr)) {
            filteredArr.push(elem);
        }
    }

    return filteredArr;
}

filterArr([1,2,3,4,5,6,7], (n, idx) => idx % 2);


const products = [
    { name: "bottle", color: 'white', price: 20000 },
    { name: "chair", color: 'red', price: 4567 },
    { name: "TV", color: 'black', price: 56789 },
    { name: "AC", color: 'blue', price: 234 },
    { name: "laptop", color: 'green', price: 34567 },
]


filterArr(products, product => product.price < 20000);