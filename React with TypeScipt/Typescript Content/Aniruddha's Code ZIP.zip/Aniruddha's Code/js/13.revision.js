function greet() {
    console.log('hi')
}

function greet() {
    console.log('abcd')
}

greet();

const interns = [{
    name: "Aastha",
    age: 21,
    address: "Nagpur"
}, {
    name: "Ritika",
    age: 21,
    address: "Nagpur"
}]

interns[0].name; // Aastha
interns[0]["age"] // 21
const key = "address";
interns[0][key]; // Nagpur

const [intern1, intern2] = interns.map(intern => intern.name).slice(0, 2);


// callbacks
const filter = (array, predicate) => {
    const filteredArray = [];

    for (let index = 0; index < array.length; index++) {
        const elem = array[index];
        if (predicate(elem, index, array)) filteredArray.push(elem);
    }

    return filteredArray;
}

filter([1, 2, 3, 4], (n, idx) => n > 2 && idx > 5);
// [3, 4]


// closures

function one() { console.log("one"); }
function two() { console.log("two"); }
function three() { console.log("three"); }
const four = () => console.log("four")

const performanceMeasuring = (callback) => {
    return () => {
        const start = Date.now();
        callback()
        const end = Date.now();
        console.log(`ran ${callback.name} in ${end - start} seconds`);
    }
}

one = performanceMeasuring(one)
two = performanceMeasuring(two)
three = performanceMeasuring(three)
four = performanceMeasuring(four);

one()
two()
three()

function add(...args) {
    return args.reduce((sum, elem) => sum + elem, 0);
}

function multiply(n1, n2, n3, n4) {
    return n1 * n2 * n3 * n4;
}

// const logger = (callback) => {
//     return (...args) => {
//         console.log(`operating on: ${args}`)
//         const result = callback(...args);                     
//         console.log(`result is ${result}`)
//     }
// }

add = logger(add);
add(1, 2);
multiply = logger(multiply);

multiply(1, 2, 3, 4, 10, 10, 10, 10, 10, 10);

// const product = l => m => n => l * m * n;

const product = (l) => {
    return (m) => {
        return (n) => {
            return l * m * n;
        }
    }
}

product(2)(3)(4); // (n) => l * m * n

function one(text) {
    console.log(text);
}

const logger = (noOfStars) => {
    return (callback) => {
        return (...args) => {
            console.log("*".repeat(noOfStars));
            const result = callback(...args);
            console.log("*".repeat(noOfStars));
            return result;
        }
    }
}

one = logger(6)(one);


one("qwertuio")



const createElement = () => {
    const subscribers = {};

    return {
        addEventListener: (event, callback) => {
            subscribers[event] ? subscribers[event].push(callback) : subscribers[event] = [callback]
        },
        onEvent: (event) => subscribers[event].forEach(sub => sub())
    }
}

const btn = createElement();

btn.addEventListener("click", () => console.log("abcd"));
btn.addEventListener("click", () => console.log("abcd1"));
btn.addEventListener("click", () => console.log("abcd2"));
btn.addEventListener("click", () => console.log("abcd3"));

btn.addEventListener("hover", () => console.log("hover"));


// whenever user does something -> browser is going to:
btn.onEvent("click");