const obj = {
    value: [1, 2, 3],

    [Symbol.iterator]() {
        let index = 0;
        const value = this.value;
        return {
            next() {
                if(index < value.length) return { value: value[index++], done: false };
                return { done: true, value: undefined }
            }
        }
    }
}

for(let val of obj) {
    console.log(val);
}

obj.map(e => console.log(e))