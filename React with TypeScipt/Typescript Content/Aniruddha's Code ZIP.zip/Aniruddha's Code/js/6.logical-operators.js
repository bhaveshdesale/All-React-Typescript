// &&
true && true // t
true && false // f
false && true // f
false && false // f

// ||
true || true // t
true || false // t
false || true // t
false || false // f

// NOT !
!true // f
!false // t

// truthy and falsy values
// 0, "", NaN, undefined, null, false are considered falsy
// all other values are truthy

// || gives first truthy value
"aniruddha" || true; // "aniruddha"
"aniruddha" || false; // "aniruddha"
0 || "aniruddha"; // "aniruddha"
// last falsy value
0 || false || ""; // 

const fetchedName = ""
const name = fetchedName || "default value";

// && gives last truthy value
"aniruddha" && true; // true
// first falsy value
"aniruddha" && false; // false

0 && "" && false; // 

const showTemplate = "aa";
const template = showTemplate && 'this is the template';