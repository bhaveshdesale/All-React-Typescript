// number

const number = 10;
const decimal = 10.5;
const negative = -10;
const notANumber = NaN;

typeof number; // 'number'

// string
const singleQuotedStr = 'this is a string';
const doubleQuotedStr = "this is also a stirng";
const backTickedStr   = `this is also a string.`;

typeof backTickedStr; // 'string'

// boolean
const isHungry = true;
const isBored = true;

// undefined
const undef = undefined; // NEVER EVER DO THIS
typeof undef; // 'undefined'

// null
const nullable = null; // NEVER EVER DO THIS
typeof nullable; // 'object' -> pseudo datatype

// array
const numbers = [1, 2, 3, 4];
const person = [
    "Aniruddha",
    32, 
    false, 
    undefined, 
    null,
    ["a", "b", "c"],
    {
        city: "pune",
        country: "India"
    }
];

// objects
const personObj = {
    name: "Aniruddha",
    age: 32,
    isHungry: true,
    humor: undefined,
    girlfriend: null,
    friends: ["a", "b", "c"],
    address: {
        city: "pune",
        country: "India"
    }
}

function greet() {
    console.log('123');
}

typeof greet; // 'function'