// ==
1 == 1; // T
1 == 2; // F
5 == "9"; // F
"a" == "a"; // T
"5" == 5; // T
false == 1; // F
true == 1; // T
0 == false; // T
5 == true; // F
false == []; // T
[] == 0; // T
false == null; // F
null == []; // F


// !=
1 != 1; // F
1 != 2; // T
5 != "9"; // T
"a" != "a"; // F
"5" != 5; // F
false != 1; // T
true != 1; // F
0 != false; // F
5 != true; // T
false != []; // F
[] != 0; // F
false != null; // T
null != []; // T

// < 
1 < 2; // true
2 < 1; // false
"a" > 1; // F
1 > "a"; // F
"a" < "z"; // T

// === USE THIS NOT ==
5 === 5; // T
5 === "5"; // F

// !== USE THIS NOT !=
5 !== 5; // F
5 !== "5"; // T



4 == 4; // T
4 == false; // F
4 == true; // F
false == ""; // T
false == "abcd"; // F
"undefined" == undefined // F
undefined == null; // T
undefined == "";  // F
[] == 4; // F
[] == 0; // T
[] === 0; // F
{} == 0; // F
{} == false; // F


// PITFALLS
{} === {} // F
[] == [] // F
[] === [] // F
{} === {} // F

// REFERENCE COMPARISONS ARE ALWAYS FALSE, UNLESS COMPARED WITH SELF.
