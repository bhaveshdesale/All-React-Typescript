const numbers = [10, 20, 30, 40, 50];

// access elements
numbers[0] // 10
numbers[1] // 20
numbers[-1] // undefined
numbers[6] // undefined

// modify elements
numbers[4] = 49 // [10, 20, 30, 40, 49];
numbers[100] = 200 // [10, 20, 30, 40, 50, 95xempty, 200];
numbers[6] // 
numbers["eighteen"] = 18

// methods
// add elements
numbers.push(60) // [10, 20, 30, 40, 50, 60]; // -> new length of array

numbers.unshift(0) // [0, 10, 20, 30, 40, 50, 60]; //  -> new length of array

numbers.splice(3, 0, 25) // [0, 10, 20, 25, 30, 40, 50, 60]; -> array of deleted elements

// remove elements
numbers.pop() // 60 | [0, 10, 20, 25, 30, 40, 50]

numbers.shift() // 0 | [10, 20, 25, 30, 40, 50]

numbers.splice(2, 1) // [25] | [10, 20, 25, 30, 40, 50]

// come back here after functions.

// cloning

// const aasthaFriends = ["Sanskruti", "Ritika"];
const meenakshiFriends = ["Vidhi", "Arya"];
// copy the reference
const aasthaFriends = meenakshiFriends;
meenakshiFriends.push("Ritika");

// create a copy of the original array
const chetanFriends = meenakshiFriends.slice();
chetanFriends.push("Vinay");

const samruddhiFriends = [
    {name: "Aniruddha", number: 1257890}
];

// SHALLOW COPY
const devanshFriends = samruddhiFriends.slice();

devanshFriends[0]; // {name: "Aniruddha", number: 1257890}
devanshFriends[0].number = 9876543;


// rest & spread operator ...
// destructuring
const computer = ["Lenovo", {}, "Intel"];
// const make = computer[0];
// const ram = computer[1];
// const chip = computer[2];

const [make, ram, chip] = computer;
const { 0: mke, 2: chp, 1: rm } = computer;
const [,,processor] = computer
const [,,,something] = computer;


const [company, ...otherAttr] = computer;
// rest operator has to be the last
// const [...all, c] = computer;

// spread operator
const computerClone = [...computer];

const oddNumbers = [1, 3, 5];
const evenNumbers = [2, 4, 6, 8, 10];
const combinedNumbers = [...oddNumbers, ...evenNumbers];