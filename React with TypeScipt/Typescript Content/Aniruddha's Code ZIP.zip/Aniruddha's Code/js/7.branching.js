const customerAge = 28;

const thirdFloorThreshold = 25;
const secondFloorThreshold = 18;

if(customerAge >= thirdFloorThreshold) {
    console.log('daruuu');
} else if (customerAge >= secondFloorThreshold) {
    console.log('weaker daruuu');
} else {
    console.log('milk');
}

// switch

const chosenPokemon = 'Pikachu';

switch(chosenPokemon) {
    case 'Pikachu':
        console.log('I choooose youuuu pikachu');
        break;
    case 'Charizard':
        console.log('Charizard main tumhe chunta hoon');
        break;
    case 'Bulbasaur':
        console.log('Jao bulbasaur, khatam kar do use');
        break;
    default:
        console.log('you dont have this pokemon');
}

// ternary operators
const message = customerAge >= thirdFloorThreshold ? "third floor" :
                customerAge >= secondFloorThreshold ? "second floor" :
                "first floor";
        
if([]) {
    console.log('I will run');
}

0 || false && [] || {} && (6 || false) || true
0 || false && [] || {} && 6 || true
0 || false || {} && 6 || true
0 || false || 6 || true
false || 6 || true
6 || true
6