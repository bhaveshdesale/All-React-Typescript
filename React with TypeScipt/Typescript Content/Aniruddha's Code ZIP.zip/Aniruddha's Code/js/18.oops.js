function Building() {
    this.name = "Nyati";
}


Building.prototype.sellFlats = function() {
    console.log('flat sold!')
}

const building = new Building();

const omf = Array.prototype.map;

const override = function(og) {
    return function(cb) {
        // throw 'NOT ALLOWED TO USE THE MAP FUNCTION!!';
        // return og.apply(this, [cb]);
        return og.call([...this, 10], cb);
    }
}

Array.prototype.map = override(omf)

const a = [1, 2, 3];
a.map(n => n ** 2);

(function(a) {
    console.log(a);
})(10);

function Building(name, floors) {
    this.name = name;
    this.floors = floors;

    this.sellFlat = function() {
        console.log(`${this.name} sold a flat`);
    }

    this.rentFlat = () => {
        console.log(`${this.name} rented a flat`);
    }
}

const anotherBuilding = new Building("Nyati", 8)
anotherBuilding.sellFlat(); // Nyati sold a flat
anotherBuilding.rentFlat(); // Nyati rented a flat

const b = {
    name: 'Nyati',
    sellFlat: function() {
        console.log(`${this.name} sold a flat`);
    },

    rentFlat:() => {
        console.log(`${this.name} rented a flat`);
    }
}

class Bottle {
    #volume

    constructor(volume, price) {
        this.#volume = volume;
        this.price = price;
    }

    drink() {
        console.log('glug glug glug');
    }

    static noOfBottles = 10;
    static something() {
        console.log('this is a static method')
    }
}

Bottle.noOfBottles;
Bottle.something();



