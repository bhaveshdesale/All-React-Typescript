console.log(number); // undefined
var number = 10;

console.log(number1); // error
let number1 = 10;


const fn = () => {
    const a = 5;
    let b = 10;
    var c = 15;

    console.log(a, b, c)
}


for (let i = 0; i < 5; i++) {
    setTimeout(() => {
        console.log(i);
    }, 1000);
}

for (const a of [1, 2, 3]) {
    console.log(a);
}

const a = 10;

const fn = () => {
    const a = 5;
}

const obj = {
    name: 'abcd',
    then() {
        console.log('then')
        return obj;
    },
    catch() {
        console.log('catch')
        return obj;
    }

}