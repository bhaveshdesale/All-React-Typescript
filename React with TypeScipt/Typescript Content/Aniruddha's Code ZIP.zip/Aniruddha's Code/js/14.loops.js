const sentence = "words";
const numbers = [1,2,3,4];
const person = { name: "anirudhda", age: 32}

// for
for(let index = 0; index < sentence.length; index++) {
    const char = sentence[index];
    console.log(char);
}

for(let index = 0; index < numbers.length; index++) {
    const number = numbers[index];
    console.log(number);
}


const keys = Object.keys();
for(let index = 0; index < keys.length; index++) {
    const key = keys[index];
    const value = person[key];
    console.log(key, value);
}

// for in loop
for(const index in sentence) {
    // index = string
    console.log(typeof index); // string
    const char = sentence[index];
    console.log(char)
}

for(const index in numbers) {
    // index = string
    console.log(typeof index); // string
    const number = numbers[index];
    console.log(number)
}

for(const key in person) {
    const value = person[key];
    console.log(value);
}

// for of loop
for(const char of sentence) {
    console.log(char);
}

for(const number of numbers) {
    console.log(number);
}

for(const [, value] of Object.entries(person)) {
    console.log(value);
}

const data = [
    { min: 30, max: 70 }
]

const getAverages = data => 
    data.reduce(
        (acc, curr) => 
            [
                (curr.min / data.length) + acc[0], // 1.25
                (curr.max / data.length) + acc[1], // 3
                ((curr.min + curr.max) / 2) / data.length + acc[2] // 
            ], 
            [0, 0, 0]
        );