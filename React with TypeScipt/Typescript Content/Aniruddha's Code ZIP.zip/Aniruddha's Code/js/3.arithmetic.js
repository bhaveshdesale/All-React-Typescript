const num1 = 10;
const num2 = 2;

// addition
const addition = num1 + num2;

// subtraction
const diff = num1 - num2;

// multiplication
const product = num1 * num2;

// division
const quotient = num1 / num2;
7 / num2; // 3.5

// remainder
const remainder = num1 % num2;

// **
const square = num1 ** num2;

let num3 = 5;
const num4 = num3++;
// 5
const num5 = ++num3;
// 7

// shortcuts
num3 += 1;
// num3 = num3 + 1;
num3 -= 1;
num3 *= 1;
num3 /= 8;
num3 **= 5;
num3 %= 6;

parseInt("7.88"); // 7
parseInt(7.88); // 7
parseInt("abcd"); // NaN
parseInt("67ds6sd"); // 67
parseInt("oiytr8765"); // NaN
parseInt(false); // NaN

Math.floor(7.8); // 7
Math.floor(7.1); // 7
Math.floor(7.5); // 7

Math.ceil(7.8); // 8

Math.round(7.8); // 8
Math.round(7.1); // 7
Math.round(7.5); // 8

Math.random(); // between 0 and 1, but not 0 and 1

Math.round((Math.random() * 5) + 10)
Math.ceil((Math.random() * 5) + 10)
Math.floor((Math.random() * 5) + 10)