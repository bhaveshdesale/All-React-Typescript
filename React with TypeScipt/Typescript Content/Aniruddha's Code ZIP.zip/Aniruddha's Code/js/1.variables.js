// NEVER EVER DO THIS.
a = 5;

// var 
// NEVER USE VAR
// DECLARATION + INITIALIZATION
var age = 15;
var age; // DECLARATION
age = 15; // INITIALIZATION

// let
// PREFER LET OVER VAR
let x = 20;
let y;
y = 10;

// const
// ALWAYS USE CONST.
const PI = 3.14;
// const distance;
// distance = 100;