const cricketPlayer = {
    [1]: "name",
    name: "Mahendra",
    surname: "Dhoni",
    age: 43,
    isGoodCaptain: false,
    battingSkills: undefined,
    captaincy: null,
    lastFiveScores: [0, 5, 20, 40, 0],
    address: {
        city: "Ranchi"
    },
    key: 123,
    "-name": "abcd",
    "was caught cheating": true,
    [1+2]: "abcd"
}

// access
cricketPlayer.age; // 43
cricketPlayer["age"]; // 43
const key = "age";
cricketPlayer[key]; // 43
cricketPlayer.key; // undefined
cricketPlayer.centuries; // undefined

// modify
cricketPlayer.age = 44;
cricketPlayer[key] = 45;
cricketPlayer["name"] = "MSD";

// add
cricketPlayer["100"] = 200;
cricketPlayer.iplTeam = "CSK";

const jNo = "jerseyNo";
cricketPlayer[jNo] = 7;

cricketPlayer[100] // 200
cricketPlayer["100"] // 200

cricketPlayer.iplTeam;
cricketPlayer["was caught cheating"];

const name = "Rohan";
const keyForName = "name";

const intern = {
    keyForName: name, // { keyForName: "Rohan" }
    [keyForName]: name, // { name: "Rohan"  }
    [name]: name  // { "Rohan": "Rohan"}
}

const naav = "naam";

const person = {
    [naav]: "Aniruddha",
    "naav": "Gajanan", // last one overrides all previous key value
    "naam": "Om"
}

person[naav];
person["naam"];
person.naam;

const company = "Coditas";

const internshipDetails = {
    company // { company: "Coditas" }
}

Object.keys(internshipDetails); // ["company"]
Object.values(internshipDetails); // ["Coditas"]


const employee = {
    isHungry: true,
    name: "Aastha",
    score: 0
};

employee.isHungry; // true
employee.isBored; // undefined
employee.score; // 0

// in operator, hasOwnProperty and hasOwn

const vme = "volume"
const bottle = {
    [vme]: "1ltr",
    color: "white",
    price: 1000,
    name: 'abcd',
    manufacturer: {
        name: "milton",
        gstin: 1234645
    }
}
bottle.manufacturer.name; // 'milton'
// copy the reference
const anotherBottle = bottle;

// destructuring
const { 
    name: nameOfBottle, 
    price: cost, 
    volume, 
    color, 
    manufacturer: { gstin }
} = bottle;

// rest & spread operator 

const computer = {
    make: "Lenovo",
    ram: "16GB",
    processor: "i7"
};

const computerClone = { ...computer };
const { ...computerClone2 } = computer;
const { ram, ...cc } = computer;

// methods
// come back here after OOPS
const TV = {
    color: "black",
    turnOn: function() {
        console.log("starting the tv");
    }
}

TV.turnOn();

const age = "age"
const address = "Kothrud"

const me = {
    name: "Aniruddha",
    [age]: 32,
    address
}