const data = {
    name: "Aniruddha"
}

JSON.stringify(1); // '1'
JSON.stringify(1.2); // '1.2'
JSON.stringify('abcd'); // '"abcd"'
JSON.stringify(false); // 'false'
JSON.stringify(undefined); // undefined. DOES NOT STRINGIFY
JSON.stringify(null); // 'null'
JSON.stringify([1,2,3]); // '[1,2,3]'
JSON.stringify([1,undefined, 'abcd']); // '[1,null,"abcd"]' 
// undefined and functions as values are going to be ignored
JSON.stringify({ name: 'abcd', age: 1, method: function() { console.log(1) }, key: null, anotherKey: undefined }); // '{ "name": "abcd", "age": 1, "key": null,  }'
JSON.stringify(() => { a = 5 }); // '() => { a =}'

JSON.parse('1'); // 1
JSON.parse('abcd'); // error
JSON.parse('"abcd"'); // "abcd"
JSON.parse('false'); // false
JSON.parse('undefined'); // error
JSON.parse('null'); // null
JSON.parse('[1, 2, 3]'); // [1, 2, 3]
JSON.parse('{ "a": 1 }'); // {a: 1}


JSON.parse(data); //error
JSON.parse(JSON.stringify({})) // creates a deep copy
// DO NOT CREATE UNNECESSARY DEEP COPIES.
// THIS IS A HEAVY OPERATION. 