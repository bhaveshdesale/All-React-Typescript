const createCounters = (starting) => {
    return () => ++starting;
}

const countFrom10 = createCounters(10);
countFrom10(); // 11
createCounters(10);

// factory pattern
const loanFactory = rateOfInterest => {
    return [
        (p, n) => p * n * rateOfInterest / 100,
        changedRate => rateOfInterest = changedRate
    ];
}


const [carLoanCalc, updateCarRate] = loanFactory(8);
const homeLoanCalc = loanFactory(10);
const personalLoanCalc = loanFactory(12);

carLoanCalc(100000, 12); // 

