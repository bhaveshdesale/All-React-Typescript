console.log('one');

setTimeout(() => {
    console.log('inside setTimeout: 10s')
}, 10000);

setTimeout(() => {
    console.log('inside setTimeout: 5s')
}, 5000);

console.log('two');

for (let i = 0; i < 10000; i++) {
    console.log(i);
}

console.log('inside setTimeout');


const getUsersAPIWithCallback = (successFn, errorFn) => {
    const users = ["a", "b", "c"];
    const duration = Math.round(Math.random() * 5000);

    setTimeout(() => {
        const random = Math.random();
        if (random >= 0.5) {
            return successFn(users);
        }

        errorFn({ message: "Somethign went wrong" });
    }, duration);

    console.log('abcd');
}

const getUserAPIWithCallback = (successFn, errorFn) => {
    const user = "A";
    const duration = Math.round(Math.random() * 5000);

    setTimeout(() => {
        const random = Math.random();
        if (random >= 0.5) {
            return successFn(user);
        }

        errorFn({ message: "Somethign went wrong" });
    }, duration);

    console.log('abcd');
}

const onUsersFetched = (employees) => {
    console.log(employees); // processing users
}

getUsersAPIWithCallback(onUsersFetched);


const getUsersAPIWithPromise = () => {
    return new Promise((resolve, reject) => {
        const users = [1, 2, 3];
        const duration = Math.round(Math.random() * 5000);

        setTimeout(() => {
            const random = Math.random();
            if (random >= 0.5) {
                return resolve(users);
            }

            reject({ message: "Something went wrong!" });
        }, duration);
    });
}

const getProductsAPIWithPromise = () => {
    return new Promise((resolve, reject) => {
        const users = [1, 2, 3];
        const duration = Math.round(Math.random() * 5000);

        setTimeout(() => {
            const random = Math.random();
            if (random >= 0.5) {
                return resolve(users);
            }

            reject({ message: "Something went wrong!" });
        }, duration);
    });
}

const getUserAPIWithPromise = () => {
    return new Promise((resolve, reject) => {
        const users = [1, 2, 3];
        const duration = Math.round(Math.random() * 5000);

        setTimeout(() => {
            const random = Math.random();
            if (random >= 0.5) {
                return resolve(users);
            }

            reject({ message: "Something went wrong!" });
        }, duration);
    });
}

const usersPromise = getUsersAPIWithPromise();

usersPromise.then(users => {
    console.log(users);
}).catch(error => {
    console.log(error.message);
})

// callback hell
const getProductsWithCallback = (successFn, errorFn) => {
    const products = ["a", "b", "c"];
    const duration = Math.round(Math.random() * 5000);

    setTimeout(() => {
        const random = Math.random();
        if (random >= 0.5) {
            return successFn(users);
        }

        errorFn({ message: "Somethine went wrong" });
    }, duration);
}

getUsersAPIWithCallback(
    (users) => {
        console.log('users fetched successfully');
        getProductsWithCallback(
            (products) => {
                console.log('products recieved');
                console.log(products, users);
                getUserAPIWithCallback(
                    (user) => {
                        console.log('user recieved successfully');
                        console.log(user);
                    },
                    (error) => {
                        console.log(error.message);
                    }
                )
            },
            (error) => {
                console.log(error.message);
            }
        )
    },
    (error) => {
        console.log('error received while calling users API');
        console.log(error.message);
    }
);

getProductsAPIWithPromise()
    .then(products => {
        console.log(products);

        return getUsersAPIWithPromise()
    }).then(users => {
        console.log(users);

        return getUserAPIWithCallback();
    }).then(user => {
        console.log(user);
    }).catch(error => {
        console.log('common error handling logic here....');
        console.log(error.message);
    }).finally(() => {
        console.log('done!!!!');
    })


const dummyAsync = () => {
    return new Promise((resolve, reject) => {
        console.log('abcd')
        setTimeout(() => {
            // return "resolved"; => not available outside of this fn
            resolve("the data passed to then callback");
            // reject("the data passed to catch callback");
        }, 3000);
    })
};

// not possible!!
const dummyAsyncWithAsyncAwait = async () => {
    setTimeout(() => {
        // return "resolved"; => not available outside of this fn
        return ([1, 2, 3]);
        // reject("the data passed to catch callback");
    }, 3000);
}


const getResult = async () => {
    console.log('running get result')
    const res = await dummyAsync();
    console.log(res);
}

const getResultWithPromise = () => {
    return new Promise((resolve, reject) => {
        console.log('running promise based get result');
        dummyAsync().then(res => {
            console.log(res);
        })
    })
}

getResult();
getResultWithPromise();
console.log("done");

const apiCallingWithAsyncAwait = async () => {
    try {
        const products = await getProductsAPIWithPromise();
        const users = await getUsersAPIWithPromise();
        const user = await getUserAPIWithPromise();

        console.log(products, users, user);
    } catch (e) {
        console.log(e);
    } finally {
        console.log("doneeeee");
    }
}


const getUsers = async () => {
    try {
        const response = await fetch("https://jsonplaceholder.typicode.com/users");
        // .json DOES NOT CONVERT TO JSON. it CONVERTS FROM JSON TO OBJECT!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        const data = await response.json();
        return data.map(d => d.name);
    } catch (e) {
        console.log(e);
    }
}

getUsers();

fetch("https://jsonplaceholder.typicode.com/food")
    .then(response => {
        return response.json()
    }).then(data => {
        console.log(data)
    }).catch(e => {
        console.log(e);
    }) 