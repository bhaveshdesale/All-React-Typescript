const select = (selector: string) => {
    const element = document.querySelector(selector);
    if(!element) throw 'NO SUCH ELEMENT';

    return element as HTMLElement;
}

export const createElement = (
    type: keyof HTMLElementTagNameMap, 
    options?: {
        text?: string;
        classNames?: string[],
        attachTo?: HTMLElement,
        event?: [type: string, (e: Event) => void];
    }
) => {
    const element = document.createElement(type);
    if(options) {
        element.textContent = options.text ?? '';
        element.classList.add(...(options.classNames || []))
        options.attachTo?.appendChild(element);
        if(options.event) element.addEventListener(options.event[0], options.event[1]);
    }

    return element;
}

export const addInternBtn = select("#add-intern");
export const addInternModal = select("#add-intern-modal");
export const addInternForm = select("#add-intern-form") as HTMLFormElement;

export const editInternModal = select("#edit-intern-modal");
export const editInternForm = select("#edit-intern-form") as HTMLFormElement;

export const deleteInternModal = select("#delete-intern-modal");
export const deleteInternYesBtn = select("#delete-intern-yes-btn");
export const deleteInternNoBtn = select("#delete-intern-no-btn");

export const internTableBody = select("#intern-table-body");