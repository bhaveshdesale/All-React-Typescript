

export const fetch = (url: string, options: { method: "GET" | "POST" | "PUT" | "DELETE", body: any, type: "SINGLE" | "MULTI" }) => {
    return new Promise((resolve, reject) => {
        const duration = Math.random() * 4000;
        setTimeout(() => {
            let db = JSON.parse((localStorage.getItem(url) || (options.type === 'MULTI' ? '[]' : '')));
            if(options.method === "GET") {
                resolve(db);
            }

            if(options.method === "POST") {
                if(options.type === 'MULTI') db.push(options.body); 
                if(options.type === 'SINGLE') db = options.body;
                 
                localStorage.setItem(url, JSON.stringify(db));

                resolve(true);
            }

            if(options.method === "PUT") {
                if(options.type === 'MULTI') {
                    const recordIndex = db.findIndex((elem: any) => elem.id === options.body.id);
                    if(recordIndex === -1) return false;

                    db[recordIndex] = options.body;
                } 
                if(options.type === 'SINGLE') db = options.body;
                localStorage.setItem(url, JSON.stringify(db));
                resolve(true)
            }

            if(options.method === "DELETE") {
                if(options.type === 'MULTI') {
                    const recordIndex = db.findIndex((elem: any) => elem.id === options.body.id);
                    if(recordIndex === -1) return false;

                    db.splice(recordIndex, 1);
                } 

                if(options.type === 'SINGLE') {
                    localStorage.removeItem(url);
                    resolve(true)
                }

                localStorage.setItem(url, JSON.stringify(db));
                resolve(true)
            }
        }, duration);
    });
}