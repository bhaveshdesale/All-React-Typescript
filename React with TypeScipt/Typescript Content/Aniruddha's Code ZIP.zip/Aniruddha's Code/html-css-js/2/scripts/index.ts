import { fetch } from "./be.js";
import { addInternBtn, addInternForm, createElement, deleteInternNoBtn, deleteInternYesBtn, editInternForm, internTableBody } from "./dom.js";
import { onAddInternClick, onAddInternFormSubmit, onDeleteInternClick, onDeleteInternNoClick, onDeleteInternYesClick, onEditInternClick, onEditInternFormSubmit } from "./event-listeners.js";
import type { Intern } from "./types.js";

addInternBtn.addEventListener("click", onAddInternClick);
addInternForm.addEventListener("submit", onAddInternFormSubmit);

editInternForm.addEventListener("submit", onEditInternFormSubmit);

deleteInternYesBtn.addEventListener("click", onDeleteInternYesClick);
deleteInternNoBtn.addEventListener("click", onDeleteInternNoClick)

export const populateInternTable = async () => {
    try {
        const interns = await fetch("interns", { method: "GET", body: null, type: 'MULTI' }) as Intern[];
        internTableBody.innerHTML = '';
        for(let intern of interns) {
            const { id, name, employee_id, scores, seat_no, track } = intern;
            const row = createElement('tr', { attachTo: internTableBody })
            createElement('td', { text: name, attachTo: row });
            createElement('td', { text: track, attachTo: row });
            // hardcoding for now
            createElement('td', { text: "7.0", attachTo: row });
            const actionTd = createElement('td', { attachTo: row });

            createElement('button', { text: 'Edit', attachTo: actionTd, classNames: ['btn', 'btn-primary'], event: ["click", (e) => onEditInternClick(intern)] });
            createElement('button', { text: 'Delete', attachTo: actionTd, classNames: ['btn', 'btn-secondary'], event: ["click", (e) => onDeleteInternClick(intern)] });
            createElement('button', { text: 'Add Score', attachTo: actionTd, classNames: ['btn', 'btn-tertiary'], event: ["click", (e) => console.log(employee_id)] });
        }

    } catch (e) {
        throw e;
    }
}

populateInternTable();