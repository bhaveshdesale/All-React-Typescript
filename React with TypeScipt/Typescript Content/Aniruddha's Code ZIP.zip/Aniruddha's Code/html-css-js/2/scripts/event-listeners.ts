import { addInternForm, addInternModal, deleteInternModal, editInternForm, editInternModal } from "./dom.js";
import { addIntern, deleteIntern, editIntern } from "./service.js";
import type { Intern } from "./types.js";


export const onAddInternClick = () => addInternModal.style.display = "grid";

export const onAddInternFormSubmit = (ev: SubmitEvent) => {
    ev.preventDefault();
    const formData = new FormData(addInternForm);
    const intern: Record<string, any> = {};

    for (let [key, value] of formData.entries()) {
        intern[key] = value;
    }

    addInternForm.reset();
    addInternModal.style.display = "none";

    addIntern(intern as Intern);
}

export const onEditInternClick = (intern: Intern) => {
    localStorage.setItem('selectedIntern', JSON.stringify(intern));

    for (let key in intern) {
        const input = editInternForm.querySelector(`#edit-intern-form [name=${key}]`);
        if (!input) continue;

        (input as HTMLInputElement).value = intern[(key as keyof Intern)] as string;
    }
    editInternModal.style.display = "grid";
}

export const onEditInternFormSubmit = (ev: SubmitEvent) => {
    ev.preventDefault();

    const selectedIntern = JSON.parse(localStorage.getItem('selectedIntern')!);
    const formData = new FormData(editInternForm);
    const intern: Record<string, any> = {};

    for (let [key, value] of formData.entries()) {
        intern[key] = value;
    }

    editInternForm.reset();
    editInternModal.style.display = "none";
    localStorage.removeItem('selectedIntern');

    editIntern({ ...selectedIntern, ...intern } as Intern);
}

export const onDeleteInternClick = (intern: Intern) => {
    localStorage.setItem('selectedIntern', JSON.stringify(intern));
    deleteInternModal.style.display = "grid";
}

export const onDeleteInternYesClick = () => {
    const selectedIntern = JSON.parse(localStorage.getItem('selectedIntern')!);
    deleteIntern(selectedIntern);
    localStorage.removeItem("selectedIntern");
    deleteInternModal.style.display = "none";
}

export const onDeleteInternNoClick = () => {
    localStorage.removeItem("selectedIntern");
    deleteInternModal.style.display = "none";
}