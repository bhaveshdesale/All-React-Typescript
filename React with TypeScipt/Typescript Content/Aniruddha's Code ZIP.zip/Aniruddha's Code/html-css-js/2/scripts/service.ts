import { fetch } from "./be.js";
import { populateInternTable } from "./index.js";
import type { Intern } from "./types.js";

export const addIntern = async (intern: Omit<Intern, "score">) => {
    intern.id = Date.now();
    await fetch("interns", { method: "POST", body: intern, type: "MULTI" });
    populateInternTable()
    return 'INTERN ADDED';
}

export const editIntern = async (intern: Omit<Intern, "score">) => {
    await fetch("interns", { method: "PUT", body: intern, type: "MULTI" });
    populateInternTable()
    return 'INTERN UPDATED';
}

export const deleteIntern = async (intern: Omit<Intern, "score">) => {
    await fetch("interns", { method: "DELETE", body: intern, type: "MULTI" });
    populateInternTable()
    return 'INTERN DELETED';
}