export interface Score {
    logic: number;
    grasping: number;
    communication: number;
    assignment: number;
    problem_solving: number;
    proactiveness: number;
}

export interface Intern {
    id: number;
    name: string;
    track: string;
    seat_no: string;
    employee_id: string;
    scores: Score[];
}