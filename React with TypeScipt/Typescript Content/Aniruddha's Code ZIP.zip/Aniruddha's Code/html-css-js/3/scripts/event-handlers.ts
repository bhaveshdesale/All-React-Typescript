import { addUserModal } from "./dom.js";

export const onAddUser = () => addUserModal.style.display = "grid";