const select = (selector: string) => {
    const elem = document.querySelector(selector);
    if(!elem) throw `${selector} was not found`;

    return elem as HTMLElement;
}

export const addUserBtn = select("#add-user");
export const addUserModal = select("#add-user-modal");