import { addUserBtn } from "./dom.js";
import { onAddUser } from "./event-handlers.js";

addUserBtn.addEventListener("click", onAddUser);