import { PAGES } from "./constants.js";
import { loginForm, loginNowBtn, registerNowBtn, registrationForm, select, selectAll } from "./dom.js";
import { handleRegisterNow, handleLoginNow, handleRegistration, handleLogin } from "./event-listener.js";

export const routeTo = (pageId: string) => {
    const page = select(pageId);
    const allPages = selectAll(".page");
    for(const page of allPages) {
        page.classList.remove("show")
    }
    history.pushState({}, '', '/' + pageId.substring(1));
    page.classList.add("show");
}

registerNowBtn.addEventListener("click", (e) => {
    e.preventDefault();
    handleRegisterNow();
})

loginNowBtn.addEventListener("click", (e) => {
    e.preventDefault();
    handleLoginNow();
})

registrationForm.addEventListener("submit", handleRegistration);
loginForm.addEventListener("submit", handleLogin);

const main = async () => {
    try {
        routeTo(PAGES.LOGIN);
    } catch(e) {
        console.log('Something went wrong');
        console.log(e);
    }
}

main();