export const getFormData = (formElem: HTMLFormElement) => {
    const formData = new FormData(formElem);
    const data: Record<string, any> = {};

    for(const [key, value] of formData.entries()) data[key] = value;

    formElem.reset();
    return data;
}

export const getRandomId = () => Date.now() + ":" + Math.random() * 9999;