export const PAGES = {
    LOGIN: "#login",
    REGISTER: "#register",
    ADMIN: "#admin",
    USER: "#user"
}