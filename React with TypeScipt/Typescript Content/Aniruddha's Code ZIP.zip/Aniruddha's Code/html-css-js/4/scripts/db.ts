type type = "MULTI" | "SINGLE";

const get = (path: string, type: type) => {
    const store = localStorage.getItem(path);
    return JSON.parse(store ?? (type === "MULTI" ? '[]' : '""'))
}

const create = (path: string, type: type, data: any) => {
    const existing = get(path, type);
    if(type === 'MULTI') {
        existing.push(data);
        data = existing;
    }

    return localStorage.setItem(path, JSON.stringify(data));
}

export default {
    get,
    create
}
