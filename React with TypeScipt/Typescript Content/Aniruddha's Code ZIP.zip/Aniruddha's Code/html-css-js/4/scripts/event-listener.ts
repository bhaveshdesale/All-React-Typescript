import { PAGES } from "./constants.js";
import db from "./db.js";
import { registrationForm, loginForm } from "./dom.js";
import { routeTo } from "./index.js";
import { getFormData, getRandomId } from "./utils.js";

export const handleRegisterNow = () => routeTo(PAGES.REGISTER);
export const handleLoginNow = () => routeTo(PAGES.LOGIN);

export const handleRegistration = (ev: SubmitEvent) => {
    ev.preventDefault();
    const userData = { id: getRandomId(), ...getFormData(registrationForm), role: "user" };

    db.create("users", "MULTI", userData);
    alert('Registered Succesfully');
    routeTo(PAGES.LOGIN);
}

export const handleLogin = (ev: SubmitEvent) => {
    ev.preventDefault();
    const credentials = getFormData(loginForm);
    if(credentials.username === "admin" && credentials.password === "admin") {
        return loginAsAdmin();
    }

    const users = db.get("users", "MULTI") as any[];
    const user = users.find(user => user.username === credentials.username && user.password === credentials.password);
    if(!user) return alert('invalid credentials');
    db.create('logged-in-user', "SINGLE" ,user);
    loginAsUser();
}

const loginAsAdmin = () => {
    routeTo(PAGES.ADMIN);
}

const loginAsUser = () => {
    routeTo(PAGES.USER);
}

