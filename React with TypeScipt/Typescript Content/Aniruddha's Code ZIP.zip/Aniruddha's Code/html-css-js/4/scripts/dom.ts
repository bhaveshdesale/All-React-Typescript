export const select = (selector: string) => {
    const element = document.querySelector(selector);
    if(!element) throw new Error(`element with selector: ${selector} not found`);

    return element as HTMLElement;
}

export const selectAll = (selector: string) => {
    const element = document.querySelectorAll(selector);
    if(!element.length) throw new Error(`element(s) with selector: ${selector} not found`);

    return element as NodeListOf<HTMLElement>;
}

export const registerNowBtn = select("#register-now-btn");
export const loginNowBtn = select("#login-now-btn");
export const registrationForm = select("#register-form") as HTMLFormElement;
export const loginForm = select("#login-form") as HTMLFormElement;
