import { Router } from "express";
import { Route } from "./src/app/routes/routes.types.js";
import { body, params, query } from "./src/utilities/validations.js";
import z from "zod";
import { userSchema } from "./src/app/feature-modules/user/user.types.js";

const router = Router();

router.post("/", 
    body(userSchema),
    (req, res, next) => {
    }
)

export default new Route("/user", router);