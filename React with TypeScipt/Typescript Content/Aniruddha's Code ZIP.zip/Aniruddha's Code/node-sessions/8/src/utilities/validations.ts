import type { NextFunction, Request, Response } from "express";
import type { ZodObject, ZodRawShape } from "zod";

const check = (type: "body" | "params" | "query") => (schema: ZodObject) => (req: Request, res: Response, next: NextFunction) => {
    try {
        req[type] = schema.parse(req[type])

        next();
    } catch (e) {
        next({ statusCode: 400, errors: e })
    }
}

export const body = check("body");
export const query = check("query")
export const params = check("params");