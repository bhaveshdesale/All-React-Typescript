import { json, type Application } from "express";
import helmet from "helmet";
import { routes } from "./routes.data.js";

export const registerMiddlewares = (app: Application) => {
    app.use(helmet());
    app.use(json());

    for(const route of routes) {
        app.use(route.path, route.router)
    }
}