import express from "express";
import { connectToPG } from "./connections/postgres.connection.js";

export const startServer = async () => {
    try {
        const app = express();

        await connectToPG();
        const { PORT } = process.env;

        app.listen(
            PORT,
            () => console.log(`SERVER STARTED ON PORT ${PORT}`)
        )
    } catch(e) {
        console.log(e);
        process.exit(1)
    }
} 