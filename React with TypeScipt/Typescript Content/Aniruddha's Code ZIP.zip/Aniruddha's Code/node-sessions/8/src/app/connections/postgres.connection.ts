import { Sequelize } from "sequelize";

export const sequelize = new Sequelize(
    process.env.DB_NAME!,
    process.env.DB_USER!,
    process.env.DB_PASSWORD!,
    {
        dialect: 'postgres'
    }
)

export const connectToPG = async () => {
    try {
        await sequelize.authenticate();
        console.log('CONNECTED TO POSTGRES');
    } catch (e) {
        console.log('COULD NOT CONNECT TO POSTGRES');
        throw e;
    }
}