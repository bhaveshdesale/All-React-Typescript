import express from "express";

const app = express();

// global/generic middleware
app.use((req, res, next) => {
    console.log(req.url);
    console.log(req.method);

    // handler(req, res, next);

    console.log('middleware 1');
    res.send('repsonse blah blah')
    // next DOES NOT STOP THE EXECUTION OF THE FN.
    // next calls the next middleware in order/line
    next();
    console.log('middleware 1 done');
});

// global/generic middleware
app.use((req, res, next) => {
    console.log('middleware 2');
    next();
    console.log('middleware 2 done');
});

// global/generic middleware
app.use((req, res, next) => {
    console.log('middleware 3');
    next();
    console.log('middleware 3 done');
});

// specific URL usecase middleware
app.use("/user", (req, res, next) => {
    console.log("user");
})

// specific method middleware
app.post("/user", (req, res, next) => {
    
})

// function handler(req, res, next) => {

// }

app.listen(3000);