import http, { IncomingMessage, type IncomingHttpHeaders } from "http";
import { match, type MatchFunction } from "path-to-regexp";

type Method = "*" | "GET" | "POST" | "PUT" | "PATCH" | "DELETE";

type Request = {
    headers: IncomingHttpHeaders,
    url: string;
    method: Method;
    body: any;
    params: any;
    query: any;
    raw: IncomingMessage
}

interface Response {
    send: (value?: any) => void;
    status: (code: number) => Response;
}

type NextFunction = (err?: any) => void;

type Middleware = (req: Request, res: Response, next: NextFunction) => void;

interface Registry {
    method: Method;
    handler: Middleware;
    endpoint: MatchFunction<Partial<Record<string, string | string[]>>>
}

const express = () => {
    const middlewareRegistry: Registry[] = [];
    const server = http.createServer((req, res) => {
        for(const registry of middlewareRegistry) {
            if(registry.endpoint === req.url && registry.method === req.method) {
                registry.handler()
            }
        }
    });

    const registerFactory = (method: Method) => {
        function register(handlers: Middleware[]): void;
        function register(path: string, handlers: Middleware[]): void;
        function register(pathOrHandlers: string | Middleware[], handlers?: Middleware[]) {
            const isPath = typeof pathOrHandlers === "string";

            const allHandlers = isPath ? handlers! : pathOrHandlers;

            for(let handler of allHandlers) {
                const registry: Registry = {
                    endpoint: isPath ? match(pathOrHandlers) : match("*"),
                    handler,
                    method
                }
                middlewareRegistry.push(registry);
            }
        }

        return register;
    }

    return {
        listen: server.listen.bind(server),
        use: registerFactory("*"),
        get: registerFactory("GET"),
        post: registerFactory("POST"),
        patch: registerFactory("PATCH"),
        put: registerFactory("PUT"),
        delete: registerFactory("DELETE")
    }
}

export default express;