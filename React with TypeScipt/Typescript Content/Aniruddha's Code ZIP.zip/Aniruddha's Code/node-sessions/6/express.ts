import http from "http";
import type { Method, Middleware, Registry, Request, Response } from "./express.types.js";
import { match } from "path-to-regexp";

const express = () => {
    const middlewareRegistry: Registry[] = [];
    const server = http.createServer((req, res) => {
        let index = 0;
        let responded = false;

        const response: Response = {
            send: (value: any) => {
                if(responded) return;
                
                responded = true;
                res.setHeader("Content-Type", "application/json");
                res.end(JSON.stringify(value));
            },
            status: function (code: number) {
                res.statusCode = code;
                return response;
            }
        }

        const request: Request = {
            url: req.url,
            method: req.method,
            headers: req.headers,
            body: undefined,
            params: {},
            query: {},
            raw: req
        }

        const next = () => {
            for (; index < middlewareRegistry.length; index++) {
                const registry = middlewareRegistry[index]!;

                const urlObj = new URL(req.url || "/", "http://localhost");
                const pathname = urlObj.pathname;
                
                const urlMatched = registry.endpoint(pathname);
                const methodMatched = isMatch(registry.method, req.method || '');
                if (urlMatched && methodMatched) {
                    request.query = Object.fromEntries(urlObj.searchParams);
                    request.params = urlMatched.params

                    index += 1;
                    registry.handler(request, response, next);
                    break;
                }
            }

            if (index === middlewareRegistry.length && !responded) response.status(404).send("Not Found")
        }

        next();
    });

    const isMatch = (s1: string, s2: string) => {
        if (s1 === "*") return true;
        if (s1 === s2) return true;

        return false;
    }

    function register(method: Method) {
        function fn(...handlers: Middleware[]): void;
        function fn(path: string, ...handlers: Middleware[]): void;
        function fn(pathOrHandler: string | Middleware, ...handlers: Middleware[]) {
            const isPath = typeof pathOrHandler === "string";
            const allHandlers = isPath ? handlers : [pathOrHandler];

            for (let handler of allHandlers) {
                const registry: Registry = {
                    method,
                    endpoint: isPath ? match(pathOrHandler) : match("/"),
                    handler
                }
                middlewareRegistry.push(registry)
            }
        }

        return fn
    }

    return {
        listen: server.listen.bind(server),
        use: register("*"),
        get: register("GET"),
        post: register("POST"),
        put: register("PUT"),
        patch: register("PATCH"),
        delete: register("DELETE"),
    }
}

export const json = (): Middleware => {
    return (req, res, next) => {
        if (req.headers["content-type"] === "application/json") {
            const allChunks: Buffer[] = [];
            req.raw.on("data", (chunk) => {
                allChunks.push(chunk);
            })

            req.raw.on("end", () => {
                req.body = JSON.parse(Buffer.concat(allChunks).toString());
                next();
            })

            return;
        }

        next();
    }
}

export default express;