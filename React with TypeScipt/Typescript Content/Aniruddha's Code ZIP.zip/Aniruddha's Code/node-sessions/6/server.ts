import express from "./framework.js";

const app = express();

app.listen(
    3000,
    () => console.log('SERVER STARTED ON PORT 3000')
)