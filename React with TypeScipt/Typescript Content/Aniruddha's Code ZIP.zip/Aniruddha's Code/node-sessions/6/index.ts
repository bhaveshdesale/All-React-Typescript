import express, { json } from "./express.js";

const app = express();

app.use(json());

app.post("/user/:id", (req, res, next) => {
    console.log('in first middleware');
    console.log(req.body);
    res.send("response")
});

app.use("/product", (req, res) => {
    console.log('in second middleware');
    res.send("response2")
});

app.listen(3000, () => console.log('SERVER STARTED ON PORT 3000'))