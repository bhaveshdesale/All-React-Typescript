import type { IncomingHttpHeaders, IncomingMessage } from "http";
import type { MatchFunction } from "path-to-regexp";

export type Request = {
    url: string | undefined;
    method: string | undefined;
    headers: IncomingHttpHeaders;
    body: any;
    params: any;
    query: any;
    raw: IncomingMessage;
};

export type Response = {
    send: (value?: any) => void;
    status: (code: number) => Response;
};

export type NextFunction = (err?: any) => void;

export type Middleware = (req: Request, res: Response, next: NextFunction) => void;

export type Method = "*" | "GET" | "POST" | "PUT" | "PATCH" | "DELETE";

export interface Registry {
    endpoint: MatchFunction<Partial<Record<string, string | string[]>>>;
    method: Method;
    handler: Middleware;
}