import express from "express";

const app = express();

app.use((req, res, next) => {
    console.log('A REQUEST WITH URL:', req.method, " CAME IN AT: ", Date.now());
    next();
})

interface User {
    id: number;
    name: string;
    age: number;
}

const users: User[] = [];

// endpoint = "/user"
// method = get
app.get("/user", (req, res, next) => {
    res.send(users);
});

// endpoint = "/user"
// method = post
app.post("/user", (req, res, next) => {
    const id = Math.floor(Math.random() * 1000000)
    users.push({
        id,
        name: "User"+id,
        age: Math.random() * 100
    })
    res.send("USER CREATED SUCCESSFULLY");
})

// endpoint = "/user"
// method = put
app.put("/user", (req, res, next) => {
    const userIndex = Math.floor(Math.random() * users.length);
    users[userIndex]!.name = "User"+userIndex
    res.send("USER UPDATED");
})

// endpoint = "/user"
// method = patch
app.patch("/user", (req, res, next) => {
    const userIndex = Math.floor(Math.random() * users.length);
    users[userIndex]!.name = "User"+userIndex
    res.send("USER UPDATED");
})

// endpoint = "/user"
// method = delete
app.delete("/user", (req, res, next) => {
    const userIndex = Math.floor(Math.random() * users.length);
    users.splice(userIndex, 1);
    res.send("USER DELETED");
})

app.listen(3000);