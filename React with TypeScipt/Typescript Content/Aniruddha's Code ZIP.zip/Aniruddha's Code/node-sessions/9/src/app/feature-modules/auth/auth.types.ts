import { ZUser } from "../user/user.types.js";

export const ZUserCreate = ZUser.omit({
    id: true
});

export const ZUserLogin = ZUser.pick({
    email: true,
    password: true
});