import z from "zod";


export const ZUser = z.object({
    id: z.string(),
    name: z.string(),
    email: z.email(),
    password: z.string()
});

export type User = z.infer<typeof ZUser>;