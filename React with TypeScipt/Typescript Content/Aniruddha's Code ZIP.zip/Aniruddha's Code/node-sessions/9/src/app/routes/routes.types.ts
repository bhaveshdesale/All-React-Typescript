import type { Router } from "express";


export class Route {
    private static registeredPaths: string[] = []
    constructor(
        public path: string,
        public router: Router
    ) {
        if(!path.startsWith("/")) throw `${path} needs to start with "/"`;
        if(Route.registeredPaths.includes(path)) throw `${path} has already been registered`;

        Route.registeredPaths.push(path);
    }
}

export type Routes = Route[];