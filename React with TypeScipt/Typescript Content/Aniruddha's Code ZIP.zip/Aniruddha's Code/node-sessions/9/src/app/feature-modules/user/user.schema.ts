import { Model,  DataTypes, type CreationOptional, UUIDV4, type InferAttributes, type InferCreationAttributes } from "sequelize";
import { sequelize } from "../../connections/pg.connection.js";
import type { User } from "./user.types.js";
import { randomUUID } from "node:crypto";

export class UserSchema extends Model<InferAttributes<UserSchema>, InferCreationAttributes<UserSchema>> {
    declare id: CreationOptional<string>;
    declare name: string;
    declare email: string;
    declare password: string;

    toSafeJson() {
        const { password, ...safe } = this.toJSON();
        return safe;
    }
}

UserSchema.init({
    id: {
        type: DataTypes.UUIDV4,
        primaryKey: true,
        defaultValue: () => randomUUID()
    },
    name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    email: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true
    },
    password: {
        type: DataTypes.STRING,
        allowNull: false,
    }
}, {
    sequelize,
    tableName: "users",
    timestamps: false,
})