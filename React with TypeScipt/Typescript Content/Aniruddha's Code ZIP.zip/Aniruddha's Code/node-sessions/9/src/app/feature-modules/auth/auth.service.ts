import { compare } from "bcryptjs";
import userService from "../user/user.service.js";
import type { User } from "../user/user.types.js";
import { AuthResponse } from "./auth.responses.js";


const register = async (user: Omit<User, "id">) => {
    try {
        const userExists = await userService.findOne({ email: user.email });
        if (userExists) throw AuthResponse.USER_ALREADY_EXISTS;

        return await userService.create(user);
    } catch (e) {
        throw e;
    }
}

const login = async (credentials: Pick<User, "email" | "password">) => {
    try {
        const user = await userService.findOne({ email: credentials.email });
        
        const passwordToCompare = user?.password ?? "$2b$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy";
        const didCompare = await compare(credentials.password, passwordToCompare);

        if (!didCompare || !user) throw AuthResponse.INVALID_CREDENTIALS;

        return user.toSafeJson()
    } catch (e) {
        throw e;
    }
}

export default {
    register,
    login
}