import express, { json } from "express";
import { registerMiddlewares } from "./routes/routes.js";
import cors from "cors";


export const startServer = () => {
    // const corsOption = {
    //     origin: ['http://localhost:5173'],
    //     credentials: true,
    //     methods: ["GET", "POST", "PUT", "DELETE"],
    // }
    const app = express();
    app.use(cors());
    registerMiddlewares(app);

    const PORT = process.env.PORT || 3000;
    app.listen(
        PORT,
        (err) => console.log(`SERVER STARTED ON PORT ${PORT} ${err}`)
    );
}