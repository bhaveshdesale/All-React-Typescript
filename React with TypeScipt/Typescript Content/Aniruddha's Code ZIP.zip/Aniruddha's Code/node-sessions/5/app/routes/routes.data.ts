

import productsRoutes from "../feature-modules/products/products.routes.js";
import userRoutes from "../feature-modules/user/user.routes.js";
import type { Routes } from "./routes.types.js";

export const routes: Routes = [
    userRoutes,
    productsRoutes
]