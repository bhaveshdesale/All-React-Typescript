import type { Router } from "express";

export class Route {
    static registeredRoutes: string[] = [];
 
    constructor(
        public path: string,
        public router: Router
    ) {
        if(!this.path.startsWith("/")) throw `${this.path} must start with "/"`
        if(Route.registeredRoutes.find(p => p === this.path)) throw `${this.path} is already registered`

        Route.registeredRoutes.push(this.path);
    }
}

export type Routes = Route[];