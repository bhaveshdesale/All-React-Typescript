import type { User, UserPredicate } from "./user.types.js";

const users: User[] = [{ id: 1, name: "Chetan Kshirsgar" }];

const getUsers = () => [...users];

const putUsers = (query: UserPredicate, user: User) => {
    const userIndex = users.findIndex(query);
    if(userIndex === -1) return false;

    users[userIndex] = user;

    return true;
}

export default {
    getUsers,
    putUsers
}