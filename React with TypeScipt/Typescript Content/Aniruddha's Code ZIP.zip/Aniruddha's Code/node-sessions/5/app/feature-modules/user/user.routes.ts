import { Router } from "express";
import userService from "./user.service.js";
import { Route } from "../../routes/routes.types.js";

const router = Router();

router.get("/", (req, res, next) => {
    const result = userService.getUsers();
    res.send(result);
})

router.put("/", (req, res, next) => {
    const result = userService.putUsers(req.body);
    res.send(result);
})

export default new Route("/user", router);