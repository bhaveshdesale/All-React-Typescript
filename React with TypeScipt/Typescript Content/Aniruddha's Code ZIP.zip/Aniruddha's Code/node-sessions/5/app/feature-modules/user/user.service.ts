import userRepo from "./user.repo.js";
import type { User } from "./user.types.js";


const getUsers = () => userRepo.getUsers();

const putUsers = (user: User) => {
    const didUpdate = userRepo.putUsers(u => u.id === user.id, user);
    if(didUpdate) return "User Updated";

    return "User Not Found";
}

export default {
    getUsers,
    putUsers
}