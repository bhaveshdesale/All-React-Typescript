import type { DataPredicate } from "../../app.types.js";

export interface User {
    id: number;
    name: string;
}

export type UserPredicate = DataPredicate<User>;