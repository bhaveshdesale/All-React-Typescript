import { Router } from "express";
import { Route } from "../../routes/routes.types.js";

const router = Router();

router.get("/", (req, res, next) => {
    
})

router.put("/", (req, res, next) => {
    
})

export default new Route("/product", router);