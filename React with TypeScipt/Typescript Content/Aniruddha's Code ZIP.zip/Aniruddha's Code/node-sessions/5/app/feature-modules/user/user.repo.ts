import userData from "./user.data.js";
import type { User, UserPredicate } from "./user.types.js";

const getUsers = () => userData.getUsers();

const putUsers = (
    query: UserPredicate, user: User
) => userData.putUsers(query, user);

export default {
    getUsers,
    putUsers
}