import { config } from "dotenv";
import { startServer } from "./app/app.js";


config();
// 1. reads a .env file
// 2. split on "\n"
// 3. on every line split on "="
// 4. put key as key and value as value in an object
// 5. merge this object with process.env 
//    process.env = { ...process.env, ...object }
startServer();