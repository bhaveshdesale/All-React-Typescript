import { Router } from "express";
import type { User } from "../interface/interface.js";

const products: User[] = [];
const router = Router();

router.get("/", (req, res, next) => {
    res.send(products);
})

router.post("/", (req, res, next) => {
    console.log("BODY RECEIVED: ", req.body);
    const product = {
        id: Math.random() * 10000,
        ...req.body
    }

    products.push(product);
    
    res.send("USER CREATED SUCCESSFULLY");
})

router.put("/", (req, res, next) => {
    const user = req.body;

    const userIndex = products.findIndex(u => u.id === user.id);

    if(userIndex === -1) return res.send("USER NOT FOUND");

    products[userIndex] = user;

    res.send("USER PUT SUCCESSFULLY");
})

router.patch("/", (req, res, next) => {
    const user = req.body;

    const userIndex = products.findIndex(u => u.id === user.id);

    if(userIndex === -1) return res.send("USER NOT FOUND");

    products[userIndex] = {
        ...products[userIndex],
        ...user
    };
    res.send("USER PATCHED SUCCESSFULLY");
})

router.delete("/:id", (req, res, next) => {
    console.log(req.query);
    console.log(req.params);

    const { id } = req.params;
    const userIndex = products.findIndex(u => u.id === Number(id));

    if(userIndex === -1) return res.send("USER NOT FOUND");

    products.splice(userIndex, 1);

    res.send("USER DELETED SUCCESSFULLY");
});

export default router;