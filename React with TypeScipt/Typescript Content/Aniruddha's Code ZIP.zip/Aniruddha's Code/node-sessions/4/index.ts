import express, { json } from "express";
import userRouter from "./routes/user.js";
import productRouter from "./routes/product.js";

export const app = express();

app.use(json());

app.use("/user", userRouter);
app.use("/product", productRouter);

app.listen(
    3000,
    () => console.log('server started on port 3000')
)