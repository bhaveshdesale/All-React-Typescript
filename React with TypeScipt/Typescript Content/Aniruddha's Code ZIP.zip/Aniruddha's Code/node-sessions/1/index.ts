import express from "express";
// express variable stores a function

// app = express application object
const app = express();

// const respond = () => console.log('hi');

// use respond function whenever there is any incoming request
// express calls the respond function whenever the request comes in.
// app.use(respond);

// middleware function
// express passes 3 arguments
// 1. request object -> has all the meta and data of the incoming req
// 2. response object -> helper object, helps us to send response back
// 3. next => we will come back to this later.
app.use((req, res, next) => {
    res.send("this is the response");
    console.log('direct callback passed');
    next();
});

app.use((req, res, next) => {
    // res.send("this is the response2");
    console.log('direct callback2 passed');
});


app.listen(3000);
// BASEURL =>
// http://localhost:3000