import style from "./App.module.scss";
import { useState } from "react";
import Counter from "./components/Counter/Counter";


const App = () => {

  const [count, setCount] = useState(0);
  const handleIncrement = () => setCount(count + 1);

  const [count2, setCount2] = useState(0);
  const handleIncrement2 = () => setCount2(count2 + 1);
  
  return <div className={style.App}>
    <Counter count={count} handleIncrement={handleIncrement2} />
    <Counter count={count2} handleIncrement={handleIncrement}/>
  </div>
}

export default App;