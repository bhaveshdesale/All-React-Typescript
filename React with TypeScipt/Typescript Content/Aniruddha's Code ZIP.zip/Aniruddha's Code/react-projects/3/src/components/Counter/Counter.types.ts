export interface CounterProps {
    count: number;
    handleIncrement: () => void;
}