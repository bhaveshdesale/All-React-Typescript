import styles from "./Button.module.scss";
import type { ButtonProps } from "./Button.types";

const Button = ({children, className, ...props}: ButtonProps) => {
    return (
        <button className={styles.Btn} {...props}>{children}</button>
    )
}

export default Button;