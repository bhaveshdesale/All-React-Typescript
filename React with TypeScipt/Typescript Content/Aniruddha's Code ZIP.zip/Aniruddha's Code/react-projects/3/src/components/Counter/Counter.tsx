import { useState } from "react";
import Button from "../Button/Button";
import styles from "./Counter.module.scss";
import type { CounterProps } from "./Counter.types";

const Counter = ({ count, handleIncrement }: CounterProps) => {
    return (
        <div className={styles.Counter}>
            <h3>{count}</h3>
            <Button onClick={handleIncrement}>Increment</Button>
        </div>
    )
}

export default Counter;