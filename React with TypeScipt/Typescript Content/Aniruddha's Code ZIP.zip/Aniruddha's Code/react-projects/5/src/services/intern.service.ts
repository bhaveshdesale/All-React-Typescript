export type Track = "angular" | "react" | "node" | "genai";

export interface Intern {
    id: string;
    name: string;
    track: Track;
    mentor: string;
}

const getInterns = async () => {
    const interns = JSON.parse(localStorage.getItem('interns') ?? '[]') as Intern[];
    return interns;
}

const addIntern = async (intern: Omit<Intern, "id">) => {
    const interns = await getInterns();
    interns.push({ id: Date.now().toString(), ...intern });
    localStorage.setItem('interns', JSON.stringify(interns));
}

const updateIntern = async (intern: Intern) => {
    const interns = await getInterns();
    const internIndex = interns.findIndex(i => i.id === intern.id);
    if(internIndex === -1) return;
    
    interns[internIndex] = intern;
    localStorage.setItem('interns', JSON.stringify(interns));
}

const deleteIntern = async (intern: Intern) => {
    const interns = await getInterns();
    const internIndex = interns.findIndex(i => i.id === intern.id);
    if(internIndex === -1) return;
    
    interns.splice(internIndex, 1);
    localStorage.setItem('interns', JSON.stringify(interns));
}

export default {
    getInterns,
    addIntern,
    updateIntern,
    deleteIntern
}