export interface HeaderProps {
    onAddClick: () => void;
}