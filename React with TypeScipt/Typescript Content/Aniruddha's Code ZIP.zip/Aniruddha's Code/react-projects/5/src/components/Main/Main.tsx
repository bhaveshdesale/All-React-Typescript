import { useEffect, useState } from "react";
import styles from "./Main.module.scss";
import type { Intern } from "../../services/intern.service";
import internService from "../../services/intern.service";
import { PrimaryBtn, SecondaryBtn } from "../Button/Button";

const Main = () => {
    const [interns, setInterns] = useState<Intern[]>([]);

    const getInterns = async () => {
        const interns = await internService.getInterns();
        setInterns(interns);
    }

    useEffect(() => {
        getInterns();
    }, [])

    return (
        <main className={styles.Main}>
            <div>
                <select>
                    <option value="angular">angular</option>
                    <option value="react">react</option>
                    <option value="node">node</option>
                    <option value="genai">genai</option>
                </select>
            </div>
            <table className={styles.Table}>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Track</th>
                        <th>Mentor</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        interns.map(intern => {
                            return <tr key={intern.id}>
                                <td>{intern.name}</td>
                                <td>{intern.track}</td>
                                <td>{intern.mentor}</td>
                                <td>
                                    <PrimaryBtn>Edit</PrimaryBtn>
                                    <SecondaryBtn>Delete</SecondaryBtn>
                                </td>
                            </tr>
                        })
                    }
                </tbody>
            </table>
        </main>
    )
}

export default Main;