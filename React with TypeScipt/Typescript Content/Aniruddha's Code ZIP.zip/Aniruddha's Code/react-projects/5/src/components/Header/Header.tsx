import { PrimaryBtn } from "../Button/Button";
import styles from "./Header.module.scss";
import type { HeaderProps } from "./Header.types";

const Header = ({ onAddClick }: HeaderProps) => {
    return (
        <header className={styles.Header}>
            <h1>Intern Management</h1>
            <PrimaryBtn>Add Intern</PrimaryBtn>
        </header>
    )
};

export default Header;