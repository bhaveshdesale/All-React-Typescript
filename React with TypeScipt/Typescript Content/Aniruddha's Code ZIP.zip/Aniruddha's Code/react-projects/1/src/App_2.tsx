import { Component, type ReactNode } from "react";

const Name = () => 'Aniruddha';
const App = () => <Name />;

class NameComponent extends Component {
    render(): ReactNode {
        return 'Aniruddha'
    }
}

class AppComponent extends Component {
    render(): ReactNode {
        return <NameComponent />
    }
}

export default AppComponent;