import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client';
import './index.css';
import App3 from "./App_3.tsx";


createRoot(document.getElementById('root1')!).render(
  <StrictMode>
    {/* App is a component */}
    <App3 />
  </StrictMode>,
)

