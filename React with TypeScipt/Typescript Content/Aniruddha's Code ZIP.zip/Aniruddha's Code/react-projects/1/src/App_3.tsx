import { Component, type ReactNode } from "react"
import "./App.css"

const App = () => {
    return (
        <>
            {/* 
                const jsx = Friend({ name: "Arya" });
                const parsedJsx = parser(jsx);
                attachToParent(parsedJsx);
            */}
            <Friend
                name="Arya"
                address="Solapur"
                mobile="1267890"
            />
            {/* 
                const jsx = Friend({});
                const parsedJsx = parser(jsx);
                attachToParent(parsedJsx);
            */}
            <Friend
                name="Jahnavi Jain"
                address="Udaipur, Rajasthan"
                mobile="123567890"
            />
            {/* 
                const jsx = Friend({});
                const parsedJsx = parser(jsx);
                attachToParent(parsedJsx);
            */}
            <Friend
                name="Jane Doe"
                address="Mars"
            />

            {/* 
                const instance = new FriendComponent({});
                const jsx = instance.render();
                const parsedJsx = parser(jsx);
                attachToParent(parsedJsx);
            */}
            <FriendComponent />
        </>
    )
}

interface FriendProps {
    name: string;
    address: string;
    mobile?: string;
}

const Friend = ({ name, address, mobile = 'No Mobile Provided' }: FriendProps) => {
    return (
        <div className="friend">
            <h2>{name}</h2>
            <div>
                <span>{mobile}</span>
                <span>|</span>
                <span>{address}</span>
            </div>
        </div>
    )
}

class FriendComponent extends Component {

    constructor(props: any) {
        super(props);
        console.log('[CLASS] props is: ', props);
    }

    render(): ReactNode {
        return (
            <div className="friend">
                <h2>Arya Tilak</h2>
                <div>
                    <span>0987654321</span>
                    <span>|</span>
                    <span>Solapur, Maharashtra</span>
                </div>
            </div>
        );
    }
}

export default App;