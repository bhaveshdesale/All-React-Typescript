import React, { Component } from "react";


const App = () => {
  // return 1;
  // return 'div';
  // return true;  // INVALID => nothing gets rendered when you return a boolean
  // return undefined; //  INVALID => nothing gets rendered when you return a undefined
  // return null; // INVALID => nothing gets rendered when you return null
  // return []; 
  // return {}; INVALID => not a valid react child -> error
  // return () => 'abcd'; INVALID => not a valid react child -> error

  // return <div>this is a div</div> 
  // return (
  //   <div>ABCD</div>
  //   <div>ABCD2</div>
  // )
  return (
    <>
      <AppComponent />
      <AppComponent />
      <AppComponent />
      <AppComponent />
    </>
  )
}

export class AppComponent extends Component {
  render() {
    return (
      <>
        <div>1</div>
        <div>2</div>
      </>
    )
  }
}

export default App;