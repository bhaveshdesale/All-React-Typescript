type Track = "react" | "angular" | "node" | "genai" | "java" | "devops" | ".net" | "data science" | "golang";

interface Score {
    logic: number;
    grasping: number;
    communication: number;
    assignments: number;
    problem_solving: number;
    proactiveness: number;
    avg: number;
}

export interface Intern {
    name: string;
    track: Track;
    scores: Score[]
}

export const data: Intern[] = [
    { 
        name: "Ananthapadmanabhan", 
        track: "react", 
        scores: [
            { logic: 7, grasping: 7, communication: 7, problem_solving: 7, assignments: 7, proactiveness: 7, avg: 7 },
            { logic: 7, grasping: 7, communication: 7, problem_solving: 7, assignments: 7, proactiveness: 7, avg: 7 },
            { logic: 7, grasping: 7, communication: 7, problem_solving: 7, assignments: 7, proactiveness: 7, avg: 7 },
            { logic: 7, grasping: 7, communication: 7, problem_solving: 7, assignments: 7, proactiveness: 7, avg: 7 },
        ] 
    },

    { 
        name: "Om Lakade", 
        track: "react", 
        scores: [
            { logic: 7, grasping: 7, communication: 7, problem_solving: 7, assignments: 7, proactiveness: 7, avg: 7 },
            { logic: 7, grasping: 7, communication: 7, problem_solving: 7, assignments: 7, proactiveness: 7, avg: 7 },
            { logic: 7, grasping: 7, communication: 7, problem_solving: 7, assignments: 7, proactiveness: 7, avg: 7 },
            { logic: 7, grasping: 7, communication: 7, problem_solving: 7, assignments: 7, proactiveness: 7, avg: 7 },
        ] 
    }
]