import { useEffect, useState } from "react";
import styles from "./App.module.scss";
import Menu from "./components/Menu/Menu"
import internsService from "./services/interns.service";
import type { Intern } from "./data/interns.data";
import Dashboard from "./components/Dashboard/Dashboard";

const App = () => {
    const [interns, setInterns] = useState<Intern[]>([]);
    const [selectedIntern, setSelectedIntern] = useState<Intern | null>(null);

    const getInterns = async () => {
        const interns = await internsService.getInterns();
        setInterns(interns);
    }

    // lifecycle hook
    useEffect(() => {
        getInterns();
    }, [])

    const handleMenuItemClick = (intern: Intern) => setSelectedIntern(intern);

    return (
        <div className={styles.App}>
            <Menu 
                interns={interns}
                onMenuItemClick={handleMenuItemClick}
            />
            <Dashboard 
                intern={selectedIntern}
            />
        </div>
    )
}

export default App;