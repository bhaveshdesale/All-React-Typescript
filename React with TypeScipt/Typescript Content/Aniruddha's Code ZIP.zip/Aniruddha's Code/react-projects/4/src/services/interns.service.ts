import { data } from "../data/interns.data"

const getInterns = async () => {
    return data;
}

export default {
    getInterns
}