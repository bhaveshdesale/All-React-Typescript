import type { Intern } from "../../data/interns.data";

export interface DashboardProps {
    intern: Intern | null
}