import MenuItem from "../MenuItem/MenuItem";
import styles from "./Menu.module.scss";
import type { MenuProps } from "./Menu.types";

const Menu = ({ interns, onMenuItemClick }: MenuProps) => {
    return (
        <nav className={styles.Menu}>
            {
                interns.map(intern => <MenuItem 
                    key={intern.name}
                    name={intern.name}
                    onItemClick={() => onMenuItemClick(intern)}
                />)
            }
        </nav>
    )
}

export default Menu;