import type { PropsWithChildren } from "react";

export interface PillProps extends PropsWithChildren {}