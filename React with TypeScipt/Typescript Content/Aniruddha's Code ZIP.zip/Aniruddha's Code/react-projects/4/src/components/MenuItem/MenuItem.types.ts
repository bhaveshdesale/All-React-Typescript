export interface MenuItemProps {
    name: string;
    onItemClick: () => void;
}