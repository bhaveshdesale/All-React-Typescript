import styles from "./MenuItem.module.scss";
import type { MenuItemProps } from "./MenuItem.types";

const MenuItem = ({ name, onItemClick }: MenuItemProps) => {
    return (
        <div className={styles.MenuItem} onClick={onItemClick}>
            <span>{name}</span>
        </div>
    )
}

export default MenuItem;