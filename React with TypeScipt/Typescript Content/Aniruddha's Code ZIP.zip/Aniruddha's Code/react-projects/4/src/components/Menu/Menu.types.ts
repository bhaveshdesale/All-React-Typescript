import type { Intern } from "../../data/interns.data";

export interface MenuProps {
    interns: Intern[];
    onMenuItemClick: (intern: Intern) => void;
}