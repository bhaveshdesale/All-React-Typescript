import Pill from "../Pill/Pill";
import styles from "./Dashboard.module.scss";
import type { DashboardProps } from "./Dashboard.types";

const Dashboard = ({ intern }: DashboardProps) => {
    if(!intern) return <div></div>

    return (
        <div className={styles.Dashboard}>
            <h2>{intern.name}</h2>
            <Pill>{intern.track}</Pill>
        </div>
    )
}

export default Dashboard