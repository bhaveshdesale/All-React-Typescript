import styles from "./Pill.module.scss";
import type { PillProps } from "./Pill.types";

const Pill = ({ children }: PillProps) => {
    return (
        <span className={styles.Pill}>{children}</span>
    )
}

export default Pill;