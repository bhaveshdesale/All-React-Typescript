import type { Server } from "../components/Server/Server.types";


export const getServers = () => {
    try {
        const servers: Server[] = [
            { id: 1, name: "EC2", status: "ON" },
            { id: 2, name: "S3", status: "OFF" },
            { id: 3, name: "EKS", status: "ON" }
        ];

        return servers;
    } catch (e) {
        throw e;
    }
}