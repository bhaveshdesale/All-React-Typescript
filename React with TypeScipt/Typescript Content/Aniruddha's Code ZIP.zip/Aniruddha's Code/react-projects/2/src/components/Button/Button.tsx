import styles from "./Button.module.scss"
import type { ButtonProps } from "./Button.types.ts"

const Button = ({ children, className, ...props }: ButtonProps) => {
    return (
        <button {...props} className={[styles.button, className].join(" ")}>
            {children}
        </button>
    );
};

export const PrimaryButton = (props: ButtonProps) => {
    return <Button {...props} className={styles.PrimaryButton}></Button>
}

export const SecondaryButton = (props: ButtonProps) => {
    return <Button {...props} className={styles.SecondaryButton}></Button>
}

export default Button;
