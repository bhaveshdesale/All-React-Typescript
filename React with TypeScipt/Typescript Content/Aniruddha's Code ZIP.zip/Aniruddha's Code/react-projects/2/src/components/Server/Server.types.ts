export interface Server {
    id: number;
    name: string;
    status: "ON" | "OFF";
}

export interface ServerProps extends Omit<Server, "id"> {}