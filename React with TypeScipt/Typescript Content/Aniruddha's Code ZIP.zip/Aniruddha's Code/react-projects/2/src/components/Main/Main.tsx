import { getServers } from "../../services/server.service";
import ServerList from "../ServerList/ServerList";
import styles from "./Main.module.scss";

const Main = () => {
    const servers = getServers();

    return (
        <main className={styles.main}>
            <ServerList servers={servers} />
        </main>
    )
}

export default Main;