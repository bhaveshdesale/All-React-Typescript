import Server from "../Server/Server";
import styles from "./ServerList.module.scss";
import type { ServerListProps } from "./ServerList.types";


const ServerList = ({ servers }: ServerListProps) => {
    return (
        <>
            {
                servers.map(
                    server => <Server
                        key={server.id} 
                        name={server.name} 
                        status={server.status} 
                    />
                )
            }
        </>
    )
}

export default ServerList