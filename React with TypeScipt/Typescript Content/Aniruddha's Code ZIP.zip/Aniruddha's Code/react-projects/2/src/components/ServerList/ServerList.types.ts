import type { Server } from "../Server/Server.types";

export interface ServerListProps {
    servers: Server[]
}