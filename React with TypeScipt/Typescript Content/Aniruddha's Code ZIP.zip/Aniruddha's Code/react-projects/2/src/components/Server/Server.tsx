import { useState } from "react";
import { SecondaryButton } from "../Button/Button";
import styles from "./Server.module.scss";
import type { ServerProps } from "./Server.types";

const Server = ({ name, status }: ServerProps) => {
    // const nameState = useState(name);
    // nameState = [value, dispatchFn]
    const [naam, updateName] = useState(name);

    return (
        <div className={styles.server}>
            <h2>{naam}</h2>
            <span>{status}</span>
            {/* Content Projection */}
            {/* 
                Button({ 
                    className: '_toggle_btn_679_J', 
                    onClick: () => console.log(name), 
                    children: 'Toggle Status'  
                })
            */}
            <SecondaryButton onClick={() => updateName(naam + 'change')}>
                Toggle Status
            </SecondaryButton>
        </div>
    )
}


export default Server;