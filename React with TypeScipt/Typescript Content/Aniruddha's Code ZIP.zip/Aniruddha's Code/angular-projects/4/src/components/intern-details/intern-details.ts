import { Component, input } from '@angular/core';
import { Intern } from '../../services/intern-service';

@Component({
  selector: 'app-intern-details',
  imports: [],
  templateUrl: './intern-details.html',
  styleUrl: './intern-details.scss',
})
export class InternDetails {
  intern = input.required<Intern>();
}
