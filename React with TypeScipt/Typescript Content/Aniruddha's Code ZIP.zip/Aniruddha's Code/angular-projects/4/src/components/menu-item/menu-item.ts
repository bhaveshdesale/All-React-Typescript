import { Component, input, output } from '@angular/core';

@Component({
  selector: 'app-menu-item',
  imports: [],
  templateUrl: './menu-item.html',
  styleUrl: './menu-item.scss',
})
export class MenuItem {
  name = input.required<string>();
  onmenuclick = output();

  onItemClick() {
    this.onmenuclick.emit();
  }
}
