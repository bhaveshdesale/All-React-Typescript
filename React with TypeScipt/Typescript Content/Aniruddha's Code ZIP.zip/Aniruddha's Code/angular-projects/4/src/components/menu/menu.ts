import { Component, input, OnInit, output } from '@angular/core';
import { Intern } from '../../services/intern-service';
import { MenuItem } from "../menu-item/menu-item";

@Component({
  selector: 'app-menu',
  imports: [MenuItem],
  templateUrl: './menu.html',
  styleUrl: './menu.scss',
})
export class Menu implements OnInit {
  interns = input.required<Intern[]>();
  itemclick = output<Intern>()

  ngOnInit(): void {
    console.log(this.interns())
  }

  handleItemClick(intern: Intern) {
    this.itemclick.emit(intern)
  }
}
