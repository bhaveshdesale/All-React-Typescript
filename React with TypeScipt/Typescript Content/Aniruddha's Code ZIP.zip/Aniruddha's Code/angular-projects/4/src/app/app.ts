import { Component, inject, OnInit, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Menu } from '../components/menu/menu';
import { InternDetails } from '../components/intern-details/intern-details';
import { Intern, InternService } from '../services/intern-service';

@Component({
  selector: 'app-root',
  imports: [Menu, InternDetails],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App implements OnInit {
  internService = inject(InternService);
  interns = signal<Intern[]>([]);
  selectedIntern = signal<Intern | null>(null);

  ngOnInit(): void {
    this.getInterns();
  }

  getInterns() {
    const interns = this.internService.getInterns();
    this.interns.set(interns);
  }

  handleMenuClick(intern: Intern) {
    this.selectedIntern.set({ ...intern });
  }

}
