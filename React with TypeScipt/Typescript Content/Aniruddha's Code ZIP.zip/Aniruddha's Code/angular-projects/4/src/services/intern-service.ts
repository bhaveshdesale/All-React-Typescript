import { Injectable } from '@angular/core';

export interface Score {
  logic: number;
  grasping: number;
  communication: number;
  problem_solving: number;
  assignments: number;
  proactiveness: number;
  average: number;
}

export interface Intern {
  name: string;
  track: string;
  scores: Score[]
}

@Injectable({
  providedIn: 'root',
})
export class InternService {
  private interns: Intern[] = [
    { name: 'Aniruddha', track: 'ALL', scores: [{ logic: 6, assignments: 6, grasping: 6, communication: 6, average: 6, proactiveness: 6, problem_solving: 6 }, { logic: 6, assignments: 6, grasping: 6, communication: 6, average: 6, proactiveness: 6, problem_solving: 6 },{ logic: 6, assignments: 6, grasping: 6, communication: 6, average: 6, proactiveness: 6, problem_solving: 6 },{ logic: 6, assignments: 6, grasping: 6, communication: 6, average: 6, proactiveness: 6, problem_solving: 6 },{ logic: 6, assignments: 6, grasping: 6, communication: 6, average: 6, proactiveness: 6, problem_solving: 6 },{ logic: 6, assignments: 6, grasping: 6, communication: 6, average: 6, proactiveness: 6, problem_solving: 6 },{ logic: 6, assignments: 6, grasping: 6, communication: 6, average: 6, proactiveness: 6, problem_solving: 6 },{ logic: 6, assignments: 6, grasping: 6, communication: 6, average: 6, proactiveness: 6, problem_solving: 6 },{ logic: 6, assignments: 6, grasping: 6, communication: 6, average: 6, proactiveness: 6, problem_solving: 6 },{ logic: 6, assignments: 6, grasping: 6, communication: 6, average: 6, proactiveness: 6, problem_solving: 6 }]},
    { name: 'Aastha', track: 'Angular', scores: [{ logic: 6, assignments: 6, grasping: 6, communication: 6, average: 6, proactiveness: 6, problem_solving: 6 }]},
    { name: 'Meenakshi', track: 'Node', scores: [{ logic: 6, assignments: 6, grasping: 6, communication: 6, average: 6, proactiveness: 6, problem_solving: 6 }]},
    { name: 'Devansh', track: 'React', scores: [{ logic: 6, assignments: 6, grasping: 6, communication: 6, average: 6, proactiveness: 6, problem_solving: 6 }]},
    { name: 'Ishita', track: 'GenAI', scores: [{ logic: 6, assignments: 6, grasping: 6, communication: 6, average: 6, proactiveness: 6, problem_solving: 6 }]},
    { name: 'Anshul', track: 'Java', scores: [{ logic: 6, assignments: 6, grasping: 6, communication: 6, average: 6, proactiveness: 6, problem_solving: 6 }]},
  ]

  getInterns() {
    return this.interns;
  }
}
