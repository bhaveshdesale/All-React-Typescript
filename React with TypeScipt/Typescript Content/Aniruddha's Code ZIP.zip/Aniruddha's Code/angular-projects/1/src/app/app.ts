import { Component } from "@angular/core";
import { Header } from "../header/header";
import { Main } from "../main/main";
import { Footer } from "../footer/footer";

@Component({
  selector: 'app-root',
  templateUrl: './app.html',
  styleUrl: './app.scss',
  imports: [
    Header,
    Main,
    Footer
]
})
export class App {}