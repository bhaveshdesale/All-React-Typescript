import { Component, inject, OnInit } from '@angular/core';
import { IServer } from "../server/server";
import { ServerList } from '../server-list/server-list';
import { Server } from '../services/server';

@Component({
  selector: 'app-main',
  imports: [ServerList],
  templateUrl: './main.html',
  styleUrl: './main.scss',
})
export class Main implements OnInit {
  serverService = inject(Server);
  serverList: IServer[] = []

  ngOnInit(): void {
    this.getServers();
  }
  
  getServers() {
    this.serverList = this.serverService.getServers()
  }
}
