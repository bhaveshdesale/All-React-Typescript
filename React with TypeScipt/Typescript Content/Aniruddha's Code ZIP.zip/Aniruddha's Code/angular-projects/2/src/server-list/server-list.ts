import { Component, input } from '@angular/core';
import { IServer, Server } from '../server/server';

@Component({
  selector: 'app-server-list',
  imports: [Server],
  templateUrl: './server-list.html',
  styleUrl: './server-list.scss',
})
export class ServerList {
  servers = input.required<IServer[]>();
}
