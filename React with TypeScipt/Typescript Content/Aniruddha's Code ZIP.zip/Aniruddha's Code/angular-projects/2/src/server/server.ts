import { Component, input } from '@angular/core';

export interface IServer {
  name: string;
  status: "ON" | "OFF"
}

@Component({
  selector: 'app-server',
  imports: [],
  templateUrl: './server.html',
  styleUrl: './server.scss',
})
export class Server {
  server = input.required<IServer>();
}
