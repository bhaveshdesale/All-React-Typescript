import { Injectable } from '@angular/core';
import { IServer } from '../server/server';

@Injectable({
  providedIn: 'root',
})
export class Server {
  private serverList: IServer[] = [
    { name: 'AWS', status: "OFF" },
    { name: 'Azure', status: "ON" },
    { name: 'GCP', status: "ON" },
    { name: 'VPS', status: "OFF" },
  ]

  getServers() {
    return this.serverList;
  }  
}
