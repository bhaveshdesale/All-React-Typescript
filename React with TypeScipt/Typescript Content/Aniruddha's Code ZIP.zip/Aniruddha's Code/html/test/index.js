const findDistinctTeams = l => [...l.reduce((s, e) => s.add(e.team), new Set())];

findDistinctTeams([
    { team: "A", player: "A1" },
    { team: "A", player: "A2" },
    { team: "A", player: "A3" },
    { team: "B", player: "B1" },
    { team: "B", player: "B2" },
    { team: "B", player: "B3" }
])